"""shipfast-agent/discovery.py — Git 后端服务发现（Gitee API）

Agent 启动时自动注册到 Gitee 仓库，运行期间维持心跳，关闭时自动注销。

对应 Go 实现: internal/discovery/git_backend.go
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import socket
from datetime import datetime, timezone
from dataclasses import dataclass, asdict
from typing import Optional

import httpx

logger = logging.getLogger("shipfast-agent.discovery")

# ========== 数据模型 ==========

@dataclass
class AgentInfo:
    alias: str
    host: str
    port: int
    token: str
    scheme: str = "https"
    version: str = ""
    labels: str = ""
    last_seen: str = ""
    created_at: str = ""


# ========== Git 后端 ==========

GITEE_API = "https://gitee.com/api/v5"
HEARTBEAT_INTERVAL = 60        # Git 模式心跳间隔（秒），避免 API 限流
HTTP_TIMEOUT = 15.0


class GitDiscovery:
    """使用 Gitee 仓库做服务发现后端。

    每个 Agent 存为 agents/{alias}.yaml 文件（JSON 格式）。
    """

    def __init__(self, repo_url: str, token: str) -> None:
        self._repo_url = repo_url
        self._owner, self._repo = self._parse_url(repo_url)
        self._token = token
        self._client: Optional[httpx.AsyncClient] = None
        self._running = False
        self._on_redirect: Optional[callable] = None

    @property
    def repo_url(self) -> str:
        """当前仓库地址"""
        return self._repo_url

    def set_on_redirect(self, callback: callable) -> None:
        """设置迁移回调：callback(new_repo, new_token) → 返回时迁移已完成"""
        self._on_redirect = callback

    # ---------- 迁移 ----------

    def reconfigure(self, new_repo_url: str, new_token: str) -> None:
        """切换仓库（不涉及注册/注销，只更新内部状态）"""
        self._repo_url = new_repo_url
        self._owner, self._repo = self._parse_url(new_repo_url)
        self._token = new_token
        # 重建 HTTP 客户端（旧的会在 close/迁移时关闭）
        self._client = httpx.AsyncClient(timeout=HTTP_TIMEOUT)
        logger.info("发现后端已切换至: %s/%s", self._owner, self._repo)

    async def check_redirect(self) -> Optional[dict]:
        """检查仓库中是否存在 agents/.redirect 迁移指令。

        返回 {"repo": "...", "token": "..."} 或 None。
        """
        try:
            f = await self._get_file("agents/.redirect")
            if not f:
                return None
            content_bytes = base64.b64decode(f["content"])
            redirect = json.loads(content_bytes)
            new_repo = redirect.get("repo", "")
            new_token = redirect.get("token", "")
            if new_repo and new_token:
                logger.info("检测到迁移指令: %s", new_repo)
                return redirect
        except Exception:
            logger.debug("检查 .redirect 失败（忽略）", exc_info=True)
        return None

    @property
    def running(self) -> bool:
        return self._running

    # ---------- URL 解析 ----------

    @staticmethod
    def _parse_url(url: str) -> tuple[str, str]:
        """解析 Gitee 仓库地址，返回 (owner, repo)"""
        u = url.rstrip("/").removesuffix(".git")
        u = u.removeprefix("https://gitee.com/")
        u = u.removeprefix("http://gitee.com/")
        parts = u.split("/", 1)
        if len(parts) != 2 or not parts[0] or not parts[1]:
            raise ValueError(
                f"无法解析仓库地址: {url}（格式应为 https://gitee.com/owner/repo）"
            )
        return parts[0], parts[1]

    def _api_path(self, file_path: str) -> str:
        """构建 Gitee API 文件路径"""
        return f"{GITEE_API}/repos/{self._owner}/{self._repo}/contents/{file_path}"

    def _ensure_client(self) -> httpx.AsyncClient:
        """确保 HTTP 客户端已初始化"""
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=HTTP_TIMEOUT)
        return self._client

    # ---------- Gitee API 封装 ----------

    async def _get_file(self, path: str) -> Optional[dict]:
        """获取单个文件信息，返回 Gitee API 响应的 dict，不存在返回 None"""
        url = f"{self._api_path(path)}?access_token={self._token}"
        resp = await self._ensure_client().get(url)
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        return resp.json()

    async def _create_file(self, path: str, content: str, message: str) -> None:
        """创建新文件"""
        encoded = base64.b64encode(content.encode()).decode()
        body = {
            "access_token": self._token,
            "content": encoded,
            "message": message,
        }
        url = self._api_path(path)
        resp = await self._ensure_client().post(url, json=body)
        if resp.status_code >= 400:
            logger.error("创建文件失败 %s: %s", path, resp.text)
            resp.raise_for_status()

    async def _update_file(self, path: str, content: str, sha: str, message: str) -> None:
        """更新已有文件"""
        encoded = base64.b64encode(content.encode()).decode()
        body = {
            "access_token": self._token,
            "content": encoded,
            "sha": sha,
            "message": message,
        }
        url = self._api_path(path)
        resp = await self._ensure_client().put(url, json=body)
        if resp.status_code >= 400:
            logger.error("更新文件失败 %s: %s", path, resp.text)
            resp.raise_for_status()

    async def _delete_file(self, path: str, sha: str, message: str) -> None:
        """删除文件"""
        body = {
            "access_token": self._token,
            "sha": sha,
            "message": message,
        }
        url = self._api_path(path)
        resp = await self._ensure_client().request("DELETE", url, json=body)
        if resp.status_code >= 400:
            logger.error("删除文件失败 %s: %s", path, resp.text)
            resp.raise_for_status()

    # ---------- Backend 接口 ----------

    async def register(self, info: AgentInfo) -> None:
        """注册 Agent：创建 agents/{alias}.yaml"""
        now = datetime.now(timezone.utc).isoformat()
        info.last_seen = now
        info.created_at = now
        content = json.dumps(asdict(info), ensure_ascii=False, indent=2)
        path = f"agents/{info.alias}.yaml"

        existing = await self._get_file(path)
        if existing:
            await self._update_file(path, content, existing["sha"], f"register {info.alias}")
        else:
            await self._create_file(path, content, f"register {info.alias}")
        logger.info("Agent '%s' 已注册到 Git 仓库（%s/%s）", info.alias, self._owner, self._repo)

    async def heartbeat(self, alias: str) -> None:
        """心跳：更新 LastSeen 时间戳"""
        path = f"agents/{alias}.yaml"
        f = await self._get_file(path)
        if not f:
            logger.warning("heartbeat: agent '%s' 文件不存在，跳过", alias)
            return

        content_bytes = base64.b64decode(f["content"])
        info_data = json.loads(content_bytes)
        info_data["last_seen"] = datetime.now(timezone.utc).isoformat()
        content = json.dumps(info_data, ensure_ascii=False, indent=2)

        await self._update_file(path, content, f["sha"], f"heartbeat {alias}")

    async def unregister(self, alias: str) -> None:
        """注销：删除 agents/{alias}.yaml"""
        path = f"agents/{alias}.yaml"
        f = await self._get_file(path)
        if not f:
            logger.info("unregister: agent '%s' 文件已不存在", alias)
            return
        await self._delete_file(path, f["sha"], f"unregister {alias}")
        logger.info("Agent '%s' 已从 Git 仓库注销", alias)

    # ---------- 心跳循环（含 redirect 检查） ----------

    async def _heartbeat_loop(self, alias: str) -> None:
        """后台心跳循环，每次心跳后检查是否有 .redirect 迁移指令"""
        while self._running:
            await asyncio.sleep(HEARTBEAT_INTERVAL)
            if not self._running:
                break
            try:
                await self.heartbeat(alias)
                # 每次心跳后检查迁移指令
                redirect = await self.check_redirect()
                if redirect and self._on_redirect is not None:
                    logger.info("收到迁移指令，准备切换仓库...")
                    await self._on_redirect(redirect["repo"], redirect["token"])
            except asyncio.CancelledError:
                break
            except Exception:
                logger.exception("心跳/迁移检查失败")

    def start_heartbeat(self, alias: str) -> asyncio.Task:
        """启动后台心跳任务"""
        self._running = True
        return asyncio.create_task(self._heartbeat_loop(alias))

    def stop(self) -> None:
        """停止心跳"""
        self._running = False

    async def close(self) -> None:
        """关闭 HTTP 客户端"""
        self.stop()
        if self._client is not None:
            await self._client.aclose()
            self._client = None


# ========== 工具函数 ==========

def detect_public_host() -> str:
    """自动检测本机对外 IP（无法检测时返回空字符串）"""
    try:
        # 通过连接外部地址来获取本机出口 IP
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(2)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return ""


def build_agent_info(
    alias: str,
    token: str,
    host: str = "",
    port: int = 8443,
    scheme: str = "https",
    version: str = "",
    labels: str = "",
) -> AgentInfo:
    """构建 AgentInfo，host 为空时自动检测"""
    if not host:
        host = detect_public_host()
    if not host:
        host = "127.0.0.1"  # 最后的兜底
    return AgentInfo(
        alias=alias,
        host=host,
        port=port,
        token=token,
        scheme=scheme,
        version=version,
        labels=labels,
    )
