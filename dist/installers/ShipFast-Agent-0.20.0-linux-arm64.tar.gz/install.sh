﻿#!/usr/bin/env bash
# 从已解压的 Agent 目录安装（systemd / docker）
#   sudo ./install.sh              # systemd（默认）
#   sudo ./install.sh --docker     # 本目录 Docker 构建并运行
set -euo pipefail

VERSION="0.20.0"
DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="${SHIPFAST_AGENT_DIR:-/opt/shipfast-agent}"
DATA_DIR="${SHIPFAST_DATA_DIR:-/var/lib/shipfast}"
PORT="${SHIPFAST_AGENT_PORT:-8443}"
CONTAINER_NAME="${SHIPFAST_AGENT_CONTAINER:-shipfast-agent}"
MODE="${1:-systemd}"

echo "==> ShipFast Agent v${VERSION} 安装 (${MODE})"

install_systemd() {
  command -v python3 >/dev/null || { echo "需要 python3"; exit 1; }
  echo "==> 安装到 ${INSTALL_DIR}"
  mkdir -p "${INSTALL_DIR}"
  rsync -a --delete "${DIR}/" "${INSTALL_DIR}/" --exclude install.sh --exclude README.txt --exclude docker-compose.yml 2>/dev/null \
    || cp -a "${DIR}/." "${INSTALL_DIR}/"
  rm -f "${INSTALL_DIR}/install.sh"

  if [ -f "${INSTALL_DIR}/requirements.txt" ]; then
    pip3 install -r "${INSTALL_DIR}/requirements.txt" --break-system-packages 2>/dev/null \
      || pip3 install -r "${INSTALL_DIR}/requirements.txt"
  fi

  mkdir -p "${DATA_DIR}"

  # Git 服务发现环境变量（可选）
  _DISCOVERY_ENV=""
  [ -n "${SHIPFAST_AGENT_ALIAS:-}" ]      && _DISCOVERY_ENV="${_DISCOVERY_ENV}Environment=SHIPFAST_AGENT_ALIAS=${SHIPFAST_AGENT_ALIAS}"$'\n'
  [ -n "${SHIPFAST_DISCOVERY_REPO:-}" ]   && _DISCOVERY_ENV="${_DISCOVERY_ENV}Environment=SHIPFAST_DISCOVERY_REPO=${SHIPFAST_DISCOVERY_REPO}"$'\n'
  [ -n "${SHIPFAST_DISCOVERY_TOKEN:-}" ]  && _DISCOVERY_ENV="${_DISCOVERY_ENV}Environment=SHIPFAST_DISCOVERY_TOKEN=${SHIPFAST_DISCOVERY_TOKEN}"$'\n'
  [ -n "${SHIPFAST_AGENT_PUBLIC_HOST:-}" ] && _DISCOVERY_ENV="${_DISCOVERY_ENV}Environment=SHIPFAST_AGENT_PUBLIC_HOST=${SHIPFAST_AGENT_PUBLIC_HOST}"$'\n'
  [ -n "${SHIPFAST_AGENT_PUBLIC_PORT:-}" ] && _DISCOVERY_ENV="${_DISCOVERY_ENV}Environment=SHIPFAST_AGENT_PUBLIC_PORT=${SHIPFAST_AGENT_PUBLIC_PORT}"$'\n'

  cat > /etc/systemd/system/shipfast-agent.service <<EOF
[Unit]
Description=ShipFast Agent v${VERSION}
After=network.target docker.service

[Service]
Type=simple
WorkingDirectory=${INSTALL_DIR}
Environment=SHIPFAST_DATA_DIR=${DATA_DIR}
Environment=SHIPFAST_AGENT_PORT=${PORT}
Environment=SHIPFAST_AGENT_HOST=0.0.0.0
${_DISCOVERY_ENV}ExecStart=/usr/bin/python3 ${INSTALL_DIR}/main.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

  systemctl daemon-reload
  systemctl enable shipfast-agent
  systemctl restart shipfast-agent

  echo "✓ Agent 已启动 (systemd)"
  echo "  健康: curl -s http://127.0.0.1:${PORT}/health"
  sleep 2
  if [ -f "${DATA_DIR}/agent.token" ]; then
    echo "  Token: $(cat "${DATA_DIR}/agent.token")"
  else
    echo "  Token: journalctl -u shipfast-agent -n 20"
  fi
}

install_docker() {
  command -v docker >/dev/null || { echo "需要 docker"; exit 1; }
  mkdir -p "${DATA_DIR}"
  echo "==> 从本目录构建 Docker 镜像"
  docker build -t "shipfast/agent:local-${VERSION}" "${DIR}"
  docker stop "${CONTAINER_NAME}" 2>/dev/null || true
  docker rm "${CONTAINER_NAME}" 2>/dev/null || true
  docker run -d \
    --name "${CONTAINER_NAME}" \
    --restart unless-stopped \
    -p "${PORT}:8443" \
    -v "${DATA_DIR}:/var/lib/shipfast" \
    -v /var/run/docker.sock:/var/run/docker.sock \
    -e SHIPFAST_DATA_DIR=/var/lib/shipfast \
    "shipfast/agent:local-${VERSION}"
  echo "✓ Agent 已启动 (Docker)"
  echo "  健康: curl -s http://127.0.0.1:${PORT}/health"
  sleep 2
  [ -f "${DATA_DIR}/agent.token" ] && echo "  Token: $(cat "${DATA_DIR}/agent.token")" || echo "  Token: docker logs ${CONTAINER_NAME}"
}

case "$MODE" in
  --docker|docker) install_docker ;;
  --systemd|systemd|"") install_systemd ;;
  *) echo "用法: $0 [--systemd|--docker]"; exit 1 ;;
esac

echo ""
echo "下一步: shipfast server add"
