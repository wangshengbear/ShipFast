"""shipfast-agent/config.py — Agent 配置"""
from __future__ import annotations

import os
import secrets
from pathlib import Path

# 数据目录（Windows 开发环境使用用户目录）
_default_data = (
    Path.home() / ".shipfast" / "agent-data"
    if os.name == "nt"
    else Path("/var/lib/shipfast")
)
DATA_DIR = Path(os.getenv("SHIPFAST_DATA_DIR", str(_default_data)))
DATA_DIR.mkdir(parents=True, exist_ok=True)

DB_PATH = DATA_DIR / "shipfast.db"
PROJECTS_DIR = DATA_DIR / "projects"
PROJECTS_DIR.mkdir(parents=True, exist_ok=True)

# 认证 Token：环境变量优先，否则持久化或生成
TOKEN_FILE = DATA_DIR / "agent.token"


def get_token() -> str:
    """获取或生成 Agent Bearer Token"""
    env_token = os.getenv("SHIPFAST_AGENT_TOKEN")
    if env_token:
        return env_token
    if TOKEN_FILE.exists():
        return TOKEN_FILE.read_text().strip()
    token = secrets.token_urlsafe(32)
    TOKEN_FILE.write_text(token)
    TOKEN_FILE.chmod(0o600)
    return token


AGENT_TOKEN = get_token()
HOST = os.getenv("SHIPFAST_AGENT_HOST", "0.0.0.0")
PORT = int(os.getenv("SHIPFAST_AGENT_PORT", "8443"))

# Nginx 配置路径
NGINX_SITES_AVAILABLE = Path("/etc/nginx/sites-available")
NGINX_SITES_ENABLED = Path("/etc/nginx/sites-enabled")

# 保留的历史版本数
MAX_DEPLOY_HISTORY = 3

# Agent 版本（与 CLI 对齐）
VERSION = "0.20.0"

# ========== 服务发现配置（Git 后端） ==========
# 配置方式：
#   1. 持久化文件: DATA_DIR/discovery.yaml（由 API 或 .redirect 自动迁移写入，优先级最高）
#   2. 环境变量:   SHIPFAST_DISCOVERY_REPO / SHIPFAST_DISCOVERY_TOKEN
# 留空则禁用自动注册（兼容旧行为）
DISCOVERY_CONFIG_FILE = DATA_DIR / "discovery.yaml"


def _load_discovery_config() -> tuple[str, str]:
    """加载发现配置：持久化文件 > 环境变量"""
    import json as _json
    if DISCOVERY_CONFIG_FILE.exists():
        try:
            data = _json.loads(DISCOVERY_CONFIG_FILE.read_text())
            repo = data.get("repo", "")
            token = data.get("token", "")
            if repo and token:
                return repo, token
        except Exception:
            pass
    return os.getenv("SHIPFAST_DISCOVERY_REPO", ""), os.getenv("SHIPFAST_DISCOVERY_TOKEN", "")


def save_discovery_config(repo: str, token: str) -> None:
    """持久化发现配置（迁移后调用）"""
    import json as _json
    DISCOVERY_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    DISCOVERY_CONFIG_FILE.write_text(_json.dumps({"repo": repo, "token": token}))
    DISCOVERY_CONFIG_FILE.chmod(0o600)


DISCOVERY_REPO, DISCOVERY_TOKEN = _load_discovery_config()
DISCOVERY_ENABLED = bool(DISCOVERY_REPO and DISCOVERY_TOKEN)

# Agent 暴露给外部的地址（可能与监听地址不同）
# 如果未设置 PUBLIC_HOST，agent 会尝试自动检测
AGENT_ALIAS = os.getenv("SHIPFAST_AGENT_ALIAS", "")             # agent 别名，如 prd1
PUBLIC_HOST = os.getenv("SHIPFAST_AGENT_PUBLIC_HOST", "")       # 外部可访问的主机地址
PUBLIC_PORT = int(os.getenv("SHIPFAST_AGENT_PUBLIC_PORT", str(PORT)))
AGENT_SCHEME = os.getenv("SHIPFAST_AGENT_SCHEME", "https")      # http 或 https
AGENT_LABELS = os.getenv("SHIPFAST_AGENT_LABELS", "")           # 标签，逗号分隔
