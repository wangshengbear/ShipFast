"""shipfast-agent/main.py — FastAPI 入口"""
from __future__ import annotations

import asyncio
import logging
import sys
from contextlib import asynccontextmanager
from pathlib import Path

# 确保模块路径
sys.path.insert(0, str(Path(__file__).parent))

import uvicorn
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from config import (
    AGENT_TOKEN, HOST, PORT, VERSION,
    DISCOVERY_ENABLED, DISCOVERY_REPO, DISCOVERY_TOKEN,
    AGENT_ALIAS, PUBLIC_HOST, PUBLIC_PORT, AGENT_SCHEME, AGENT_LABELS,
    save_discovery_config,
)
from models import init_db
from routers import alerts, backup, deploy, drift, incidents, metrics, projects, prometheus, server, sla
from routers.auth import verify_token

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("shipfast-agent")


_discovery = None
_heartbeat_task = None


# ========== 迁移逻辑 ==========

async def _do_migrate_discovery(new_repo: str, new_token: str) -> None:
    """迁移到新仓库：注销旧仓库 → 注册新仓库 → 重启心跳"""
    global _discovery, _heartbeat_task

    old = _discovery
    if old is None:
        return

    # 1. 持久化新配置（先写盘，保证重启后生效）
    save_discovery_config(new_repo, new_token)
    logger.info("发现配置已持久化: %s", new_repo)

    # 2. 停止旧心跳
    old.stop()
    if _heartbeat_task is not None:
        _heartbeat_task.cancel()
        try:
            await _heartbeat_task
        except asyncio.CancelledError:
            pass
        _heartbeat_task = None

    # 3. 注销旧仓库
    try:
        await old.unregister(AGENT_ALIAS)
    except Exception:
        logger.exception("旧仓库注销失败（忽略）")

    # 4. 关闭旧客户端
    await old.close()

    # 5. 创建新后端并注册
    from discovery import GitDiscovery, build_agent_info
    _discovery = GitDiscovery(new_repo, new_token)
    _discovery.set_on_redirect(_on_redirect_handler)

    agent_info = build_agent_info(
        alias=AGENT_ALIAS,
        token=AGENT_TOKEN,
        host=PUBLIC_HOST,
        port=PUBLIC_PORT,
        scheme=AGENT_SCHEME,
        version=VERSION,
        labels=AGENT_LABELS,
    )
    await _discovery.register(agent_info)

    # 6. 启动新心跳
    _heartbeat_task = _discovery.start_heartbeat(AGENT_ALIAS)

    logger.info("仓库迁移完成: %s", new_repo)


async def _on_redirect_handler(new_repo: str, new_token: str) -> None:
    """心跳循环中检测到 .redirect 时调用"""
    await _do_migrate_discovery(new_repo, new_token)


# ========== 启停逻辑 ==========

async def _start_discovery():
    """启动 Git 发现服务：注册 + 心跳循环"""
    global _discovery, _heartbeat_task

    if not DISCOVERY_ENABLED:
        logger.info("服务发现未配置（未设置 DISCOVERY_REPO / DISCOVERY_TOKEN），跳过自动注册")
        return

    if not AGENT_ALIAS:
        logger.warning("服务发现已启用但未设置 AGENT_ALIAS，跳过自动注册")
        return

    from discovery import GitDiscovery, build_agent_info

    _discovery = GitDiscovery(DISCOVERY_REPO, DISCOVERY_TOKEN)
    _discovery.set_on_redirect(_on_redirect_handler)
    agent_info = build_agent_info(
        alias=AGENT_ALIAS,
        token=AGENT_TOKEN,
        host=PUBLIC_HOST,
        port=PUBLIC_PORT,
        scheme=AGENT_SCHEME,
        version=VERSION,
        labels=AGENT_LABELS,
    )
    try:
        await _discovery.register(agent_info)
        _heartbeat_task = _discovery.start_heartbeat(AGENT_ALIAS)
        logger.info(
            "服务发现已启动：alias=%s host=%s:%d scheme=%s repo=%s/%s",
            AGENT_ALIAS, agent_info.host, agent_info.port,
            agent_info.scheme, _discovery._owner, _discovery._repo,
        )
    except Exception:
        logger.exception("服务发现注册失败，Agent 仍正常运行")


async def _stop_discovery():
    """停止发现服务：注销 + 清理"""
    global _discovery, _heartbeat_task

    if _discovery is None:
        return

    try:
        await _discovery.unregister(AGENT_ALIAS)
    except Exception:
        logger.exception("注销失败（不影响关闭）")
    finally:
        _discovery.stop()
        if _heartbeat_task is not None:
            _heartbeat_task.cancel()
            try:
                await _heartbeat_task
            except asyncio.CancelledError:
                pass  # 预期的取消，无需处理
        await _discovery.close()
        _discovery = None
        _heartbeat_task = None


# ========== API 模型 ==========

class ReconfigRequest(BaseModel):
    repo: str    # 新仓库地址
    token: str   # 新 Gitee 令牌


class ReconfigResponse(BaseModel):
    ok: bool
    old_repo: str
    new_repo: str


# ========== 应用与路由 ==========

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    logger.info("ShipFast Agent v%s 启动于 %s:%s", VERSION, HOST, PORT)
    logger.info("Bearer Token: %s", AGENT_TOKEN[:8] + "...")

    # --- 启动时：自动注册到 Git 发现服务 ---
    await _start_discovery()

    yield

    # --- 关闭时：注销 ---
    await _stop_discovery()


app = FastAPI(
    title="ShipFast Agent",
    description="远程部署 Agent — 接收 CLI 指令并执行 Docker/Nginx 部署",
    version=VERSION,
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(deploy.router)
app.include_router(projects.router)
app.include_router(server.router)
app.include_router(metrics.router)
app.include_router(prometheus.router)
app.include_router(alerts.router)
app.include_router(backup.router)
app.include_router(drift.router)
app.include_router(incidents.router)
app.include_router(sla.router)


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "version": VERSION, "service": "shipfast-agent"}


# ========== 方案 C: 管理端远程迁移 API ==========

@app.post("/api/v1/discovery/reconfig", response_model=ReconfigResponse)
async def discovery_reconfig(
    body: ReconfigRequest,
    _token: str = Depends(verify_token),
) -> ReconfigResponse:
    """管理端远程下发仓库迁移指令（需要 Bearer Token 认证）"""
    global _discovery

    if _discovery is None:
        raise HTTPException(status_code=400, detail="服务发现未启用，无法迁移")

    old_repo = _discovery.repo_url

    if old_repo == body.repo:
        raise HTTPException(status_code=400, detail="新旧仓库地址相同，无需迁移")

    logger.info("收到远程迁移指令: %s → %s", old_repo, body.repo)

    try:
        await _do_migrate_discovery(body.repo, body.token)
    except Exception as e:
        logger.exception("迁移失败")
        raise HTTPException(status_code=500, detail=f"迁移失败: {e}")

    return ReconfigResponse(ok=True, old_repo=old_repo, new_repo=body.repo)


if __name__ == "__main__":
    uvicorn.run("main:app", host=HOST, port=PORT, reload=False)
