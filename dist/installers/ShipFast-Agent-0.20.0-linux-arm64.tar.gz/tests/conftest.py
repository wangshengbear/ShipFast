import sys
from pathlib import Path

# 确保 shipfast-agent 源码目录在 sys.path 中
agent_dir = Path(__file__).parent.parent
sys.path.insert(0, str(agent_dir))
