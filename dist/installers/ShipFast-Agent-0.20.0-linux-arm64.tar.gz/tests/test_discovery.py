"""测试 discovery.py — GitDiscovery URL解析、AgentInfo 构建、心跳循环"""
from __future__ import annotations

import asyncio
import json
import base64
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# ── AgentInfo ──


def test_agent_info_creation():
    from discovery import AgentInfo

    info = AgentInfo(
        alias="prd1",
        host="10.0.0.1",
        port=8443,
        token="test-token",
        scheme="https",
        version="0.20.0",
        labels="env=prod,region=us",
    )
    assert info.alias == "prd1"
    assert info.host == "10.0.0.1"
    assert info.port == 8443
    assert info.token == "test-token"
    assert info.scheme == "https"
    assert info.version == "0.20.0"
    assert info.labels == "env=prod,region=us"
    assert info.last_seen == ""


def test_agent_info_defaults():
    from discovery import AgentInfo

    info = AgentInfo(alias="dev1", host="127.0.0.1", port=8443, token="t")
    assert info.scheme == "https"  # 默认值
    assert info.version == ""
    assert info.labels == ""
    assert info.last_seen == ""
    assert info.created_at == ""


# ── URL 解析 ──


def test_parse_url_standard():
    from discovery import GitDiscovery

    owner, repo = GitDiscovery._parse_url("https://gitee.com/myorg/myrepo")
    assert owner == "myorg"
    assert repo == "myrepo"


def test_parse_url_trailing_slash():
    from discovery import GitDiscovery

    owner, repo = GitDiscovery._parse_url("https://gitee.com/myorg/myrepo/")
    assert owner == "myorg"
    assert repo == "myrepo"


def test_parse_url_with_dot_git():
    from discovery import GitDiscovery

    owner, repo = GitDiscovery._parse_url("https://gitee.com/myorg/myrepo.git")
    assert owner == "myorg"
    assert repo == "myrepo"


def test_parse_url_subgroup():
    from discovery import GitDiscovery

    owner, repo = GitDiscovery._parse_url("https://gitee.com/org/subgroup/repo")
    assert owner == "org"
    assert repo == "subgroup/repo"


def test_parse_url_invalid():
    from discovery import GitDiscovery
    import pytest

    with pytest.raises(ValueError, match="无法解析仓库地址"):
        GitDiscovery._parse_url("https://gitee.com/onlyone")


def test_parse_url_empty():
    from discovery import GitDiscovery
    import pytest

    with pytest.raises(ValueError, match="无法解析仓库地址"):
        GitDiscovery._parse_url("")


# ── API 路径构建 ──


def test_api_path():
    from discovery import GitDiscovery

    gd = GitDiscovery("https://gitee.com/org/repo", "token123")
    path = gd._api_path("agents/prd1.yaml")
    assert "org" in path
    assert "repo" in path
    assert "agents/prd1.yaml" in path
    assert "gitee.com/api/v5" in path


# ── build_agent_info ──


def test_build_agent_info_with_host():
    from discovery import build_agent_info

    info = build_agent_info(
        alias="prd1", token="t", host="192.168.1.1", port=8443,
        scheme="https", version="0.20.0", labels="env=prod",
    )
    assert info.alias == "prd1"
    assert info.host == "192.168.1.1"
    assert info.port == 8443
    assert info.token == "t"
    assert info.scheme == "https"
    assert info.version == "0.20.0"


def test_build_agent_info_auto_detect_host():
    """host 为空时自动检测本机 IP"""
    from discovery import build_agent_info

    with patch("discovery.detect_public_host", return_value="203.0.113.1"):
        info = build_agent_info(alias="prd1", token="t", host="")
        assert info.host == "203.0.113.1"


def test_build_agent_info_detect_failed_fallback():
    """检测失败时回退到 127.0.0.1"""
    from discovery import build_agent_info

    with patch("discovery.detect_public_host", return_value=""):
        info = build_agent_info(alias="prd1", token="t", host="")
        assert info.host == "127.0.0.1"


# ── GitDiscovery 注册/心跳/注销 (mock) ──

class TestGitDiscoveryMock:
    def test_register_creates_file(self):
        """首次注册创建新文件"""
        gd = _make_git_discovery()
        gd._get_file = AsyncMock(return_value=None)  # 文件不存在
        gd._create_file = AsyncMock()
        gd._update_file = AsyncMock()

        async def run():
            from discovery import AgentInfo
            info = AgentInfo(alias="prd1", host="1.2.3.4", port=8443, token="t")
            await gd.register(info)

        asyncio.run(run())
        gd._get_file.assert_called_once()
        gd._create_file.assert_called_once()
        gd._update_file.assert_not_called()

    def test_register_updates_existing(self):
        """已有文件时走更新路径"""
        gd = _make_git_discovery()
        gd._get_file = AsyncMock(return_value={"sha": "abc123", "content": ""})
        gd._create_file = AsyncMock()
        gd._update_file = AsyncMock()

        async def run():
            from discovery import AgentInfo
            info = AgentInfo(alias="prd1", host="1.2.3.4", port=8443, token="t")
            await gd.register(info)

        asyncio.run(run())
        gd._create_file.assert_not_called()
        gd._update_file.assert_called_once()

    def test_heartbeat_updates_last_seen(self):
        """心跳更新 last_seen 时间戳"""
        gd = _make_git_discovery()
        original_data = {
            "alias": "prd1", "host": "1.2.3.4", "port": 8443,
            "token": "t", "last_seen": "2024-01-01T00:00:00+00:00"
        }
        encoded = base64.b64encode(json.dumps(original_data).encode()).decode()
        gd._get_file = AsyncMock(return_value={"sha": "abc", "content": encoded})
        gd._update_file = AsyncMock()

        async def run():
            await gd.heartbeat("prd1")

        asyncio.run(run())
        # 验证调用了 _update_file，且 content 包含更新的 last_seen
        assert gd._update_file.call_count == 1
        call_args = gd._update_file.call_args
        updated_content = call_args[0][1]  # 第二个参数是 content
        updated_data = json.loads(updated_content)
        assert updated_data["last_seen"] != "2024-01-01T00:00:00+00:00"  # 已更新

    def test_heartbeat_agent_not_found(self):
        """文件不存在时心跳跳过"""
        gd = _make_git_discovery()
        gd._get_file = AsyncMock(return_value=None)
        gd._update_file = AsyncMock()

        async def run():
            await gd.heartbeat("missing-agent")

        asyncio.run(run())
        gd._update_file.assert_not_called()

    def test_unregister_deletes_file(self):
        """注销时删除文件"""
        gd = _make_git_discovery()
        gd._get_file = AsyncMock(return_value={"sha": "abc", "content": ""})
        gd._delete_file = AsyncMock()

        async def run():
            await gd.unregister("prd1")

        asyncio.run(run())
        gd._delete_file.assert_called_once()

    def test_unregister_already_gone(self):
        """文件已不存在时注销跳过"""
        gd = _make_git_discovery()
        gd._get_file = AsyncMock(return_value=None)
        gd._delete_file = AsyncMock()

        async def run():
            await gd.unregister("prd1")

        asyncio.run(run())
        gd._delete_file.assert_not_called()

    def test_reconfigure_updates_owner_repo(self):
        """reconfigure 切换仓库"""
        gd = _make_git_discovery()
        gd.reconfigure("https://gitee.com/neworg/newrepo", "newtoken")
        assert gd._repo_url == "https://gitee.com/neworg/newrepo"
        assert gd._owner == "neworg"
        assert gd._repo == "newrepo"
        assert gd._token == "newtoken"

    def test_check_redirect_found(self):
        """检测到 .redirect 迁移指令"""
        gd = _make_git_discovery()
        redirect_data = {"repo": "https://gitee.com/org2/repo2", "token": "tk2"}
        encoded = base64.b64encode(json.dumps(redirect_data).encode()).decode()
        gd._get_file = AsyncMock(return_value={"content": encoded})

        async def run():
            result = await gd.check_redirect()
            return result

        result = asyncio.run(run())
        assert result is not None
        assert result["repo"] == "https://gitee.com/org2/repo2"
        assert result["token"] == "tk2"

    def test_check_redirect_not_found(self):
        """没有 .redirect 指令"""
        gd = _make_git_discovery()
        gd._get_file = AsyncMock(return_value=None)

        async def run():
            result = await gd.check_redirect()
            return result

        result = asyncio.run(run())
        assert result is None

    def test_stop_running(self):
        """stop() 设置 _running = False"""
        gd = _make_git_discovery()
        gd._running = True
        gd.stop()
        assert not gd._running


def _make_git_discovery(repo="https://gitee.com/org/repo", token="test-token"):
    """创建测试用的 GitDiscovery，避免真实 HTTP 调用"""
    from discovery import GitDiscovery
    gd = GitDiscovery(repo, token)
    # 防止 _ensure_client 创建真实 httpx Client
    gd._client = MagicMock()
    return gd
