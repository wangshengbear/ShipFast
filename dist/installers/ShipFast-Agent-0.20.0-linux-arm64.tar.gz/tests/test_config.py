"""测试 config.py — Agent 配置、Token 管理、发现配置加载"""
from __future__ import annotations

import os
import json
import tempfile
from pathlib import Path
from unittest.mock import patch

# ── Token 生成与持久化 ──


def test_get_token_from_env():
    """环境变量 SHIPFAST_AGENT_TOKEN 优先"""
    from config import get_token

    with patch.dict(os.environ, {"SHIPFAST_AGENT_TOKEN": "env-token-123"}):
        token = get_token()
        assert token == "env-token-123"


def test_get_token_from_file():
    """持久化文件存在时读取文件"""
    from config import get_token, TOKEN_FILE

    with tempfile.TemporaryDirectory() as tmp:
        token_path = Path(tmp) / "agent.token"
        token_path.write_text("file-token-456")
        with patch("config.TOKEN_FILE", token_path):
            token = get_token()
            assert token == "file-token-456"


def test_get_token_generate_new():
    """文件不存在时自动生成新 Token"""
    from config import get_token

    with tempfile.TemporaryDirectory() as tmp:
        token_path = Path(tmp) / "agent.token"
        # 确保文件不存在
        assert not token_path.exists()
        with patch("config.TOKEN_FILE", token_path):
            token = get_token()
            assert len(token) == 43  # secrets.token_urlsafe(32) → 43 chars
            assert token_path.exists()
            assert token_path.read_text().strip() == token


def test_get_token_env_overrides_file():
    """环境变量优先级高于持久化文件"""
    from config import get_token, TOKEN_FILE

    with tempfile.TemporaryDirectory() as tmp:
        token_path = Path(tmp) / "agent.token"
        token_path.write_text("file-token")
        with patch("config.TOKEN_FILE", token_path), patch.dict(
            os.environ, {"SHIPFAST_AGENT_TOKEN": "env-override"}
        ):
            token = get_token()
            assert token == "env-override"


# ── 发现配置加载 ──


def test_discovery_config_from_env():
    """从环境变量加载发现配置"""
    from config import _load_discovery_config

    with patch.dict(os.environ, {
        "SHIPFAST_DISCOVERY_REPO": "https://gitee.com/org/repo",
        "SHIPFAST_DISCOVERY_TOKEN": "gitee-token-123",
    }):
        repo, token = _load_discovery_config()
        assert repo == "https://gitee.com/org/repo"
        assert token == "gitee-token-123"


def test_discovery_config_from_file():
    """从持久化文件加载发现配置（优先级高于环境变量）"""
    from config import _load_discovery_config, DISCOVERY_CONFIG_FILE

    with tempfile.TemporaryDirectory() as tmp:
        config_path = Path(tmp) / "discovery.yaml"
        config_path.write_text(
            json.dumps({"repo": "https://gitee.com/org/persisted", "token": "persisted-token"})
        )

        with patch("config.DISCOVERY_CONFIG_FILE", config_path), patch.dict(
            os.environ, {
                "SHIPFAST_DISCOVERY_REPO": "https://gitee.com/org/env",
                "SHIPFAST_DISCOVERY_TOKEN": "env-token",
            }
        ):
            repo, token = _load_discovery_config()
            # 文件优先
            assert repo == "https://gitee.com/org/persisted"
            assert token == "persisted-token"


def test_discovery_config_disabled_when_empty():
    """环境变量为空时发现功能禁用"""
    from config import _load_discovery_config

    with patch.dict(os.environ, {}, clear=True):
        repo, token = _load_discovery_config()
        assert repo == ""
        assert token == ""


def test_discovery_config_file_corrupted_falls_back():
    """持久化文件损坏时回退到环境变量"""
    from config import _load_discovery_config, DISCOVERY_CONFIG_FILE

    with tempfile.TemporaryDirectory() as tmp:
        config_path = Path(tmp) / "discovery.yaml"
        config_path.write_text("not valid json {{{")

        with patch("config.DISCOVERY_CONFIG_FILE", config_path), patch.dict(
            os.environ, {
                "SHIPFAST_DISCOVERY_REPO": "https://gitee.com/org/fallback",
                "SHIPFAST_DISCOVERY_TOKEN": "fallback-token",
            }
        ):
            repo, token = _load_discovery_config()
            assert repo == "https://gitee.com/org/fallback"
            assert token == "fallback-token"


# ── 发现配置持久化 ──


def test_save_discovery_config():
    """save_discovery_config 正确写入文件"""
    from config import save_discovery_config, DISCOVERY_CONFIG_FILE

    with tempfile.TemporaryDirectory() as tmp:
        config_path = Path(tmp) / "discovery.yaml"
        with patch("config.DISCOVERY_CONFIG_FILE", config_path):
            save_discovery_config("https://gitee.com/org/saved", "saved-token")

        assert config_path.exists()
        data = json.loads(config_path.read_text())
        assert data["repo"] == "https://gitee.com/org/saved"
        assert data["token"] == "saved-token"


# ── 默认值 ──


def test_default_port_and_host():
    """默认 HOST=0.0.0.0, PORT=8443"""
    from config import HOST, PORT
    # 这些模块级变量应在导入时已设置
    assert isinstance(PORT, int)
    assert PORT == 8443
    assert HOST == "0.0.0.0"
