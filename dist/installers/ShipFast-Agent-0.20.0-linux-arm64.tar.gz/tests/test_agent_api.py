"""测试 Agent FastAPI 应用 — health、认证、部署 API"""
from __future__ import annotations

import os
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest
from fastapi.testclient import TestClient


def _make_client() -> TestClient:
    """创建测试客户端，禁用发现注册避免启动时调用 Gitee API"""
    from config import AGENT_TOKEN

    with (
        patch("main._start_discovery", return_value=_async_none()),
        patch("main._stop_discovery", return_value=_async_none()),
        patch("models.init_db"),  # 跳过数据库初始化
    ):
        from main import app
        client = TestClient(app)
        # 注入 Bearer Token header
        client.headers["Authorization"] = f"Bearer {AGENT_TOKEN}"
        return client


def _async_none():
    """返回一个完成 None 的协程"""
    import asyncio
    async def _f():
        return None
    return _f()


# ── 健康检查 ──


def test_health_endpoint():
    """GET /health 返回正常状态"""
    client = _make_client()
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"
    assert data["service"] == "shipfast-agent"
    assert "version" in data


# ── 服务器状态 ──


def test_server_status_requires_auth():
    """GET /api/v1/server/status 需要认证"""
    from main import app
    with TestClient(app) as client:
        response = client.get("/api/v1/server/status")  # 无 Authorization
        assert response.status_code in (401, 403)


# ── 部署 API ──


def test_deploy_requires_auth():
    """POST /api/v1/deploy 需要认证"""
    from main import app
    with TestClient(app) as client:
        response = client.post("/api/v1/deploy", json={"name": "test"})
        assert response.status_code in (401, 403)


# ── 项目列表 ──


def test_projects_requires_auth():
    """GET /api/v1/projects 需要认证"""
    from main import app
    with TestClient(app) as client:
        response = client.get("/api/v1/projects")
        assert response.status_code in (401, 403)


# ── 发现重配置 ──


def test_discovery_reconfig_when_disabled():
    """发现未启用时返回 400"""
    from main import app

    with (
        patch("main._discovery", None),
        patch("main._start_discovery", return_value=_async_none()),
        patch("main._stop_discovery", return_value=_async_none()),
        patch("models.init_db"),
    ):
        from config import AGENT_TOKEN
        with TestClient(app) as client:
            client.headers["Authorization"] = f"Bearer {AGENT_TOKEN}"
            resp = client.post("/api/v1/discovery/reconfig", json={
                "repo": "https://gitee.com/org/repo",
                "token": "tk",
            })
            assert resp.status_code == 400
            assert "未启用" in resp.json()["detail"]


def test_discovery_reconfig_same_repo():
    """新旧仓库地址相同时返回 400"""
    from main import app
    mock_discovery = MagicMock()
    mock_discovery.repo_url = "https://gitee.com/org/repo"

    with (
        patch("main._discovery", mock_discovery),
        patch("main._start_discovery", return_value=_async_none()),
        patch("main._stop_discovery", return_value=_async_none()),
        patch("models.init_db"),
    ):
        from config import AGENT_TOKEN
        with TestClient(app) as client:
            client.headers["Authorization"] = f"Bearer {AGENT_TOKEN}"
            resp = client.post("/api/v1/discovery/reconfig", json={
                "repo": "https://gitee.com/org/repo",
                "token": "tk",
            })
            assert resp.status_code == 400
            assert "相同" in resp.json()["detail"]


# ── 请求模型 ──


def test_reconfig_request_model():
    """ReconfigRequest 模型校验"""
    from main import ReconfigRequest

    req = ReconfigRequest(repo="https://gitee.com/org/repo", token="tk")
    assert req.repo == "https://gitee.com/org/repo"
    assert req.token == "tk"


def test_reconfig_response_model():
    """ReconfigResponse 模型"""
    from main import ReconfigResponse

    resp = ReconfigResponse(ok=True, old_repo="old", new_repo="new")
    assert resp.ok is True
    assert resp.old_repo == "old"
    assert resp.new_repo == "new"
