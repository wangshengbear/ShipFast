﻿ShipFast Discovery v0.20.0 (Windows amd64)
================================

快速开始:
  1. 把二进制加入 PATH
  2. shipfast-discovery -help
  3. 参考文档启动发现服务

文档: https://shipfast.app/docs
校验: 对照 SHA256SUMS
