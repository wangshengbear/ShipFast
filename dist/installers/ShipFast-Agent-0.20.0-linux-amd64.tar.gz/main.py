"""shipfast-agent/main.py — FastAPI 入口"""
from __future__ import annotations

import logging
import sys
from contextlib import asynccontextmanager
from pathlib import Path

# 确保模块路径
sys.path.insert(0, str(Path(__file__).parent))

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from config import AGENT_TOKEN, HOST, PORT, VERSION
from models import init_db
from routers import alerts, backup, deploy, drift, incidents, metrics, projects, prometheus, server, sla

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("shipfast-agent")


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    logger.info("ShipFast Agent v%s 启动于 %s:%s", VERSION, HOST, PORT)
    logger.info("Bearer Token: %s", AGENT_TOKEN[:8] + "...")
    yield


app = FastAPI(
    title="ShipFast Agent",
    description="远程部署 Agent — 接收 CLI 指令并执行 Docker/Nginx 部署",
    version=VERSION,
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(deploy.router)
app.include_router(projects.router)
app.include_router(server.router)
app.include_router(metrics.router)
app.include_router(prometheus.router)
app.include_router(alerts.router)
app.include_router(backup.router)
app.include_router(drift.router)
app.include_router(incidents.router)
app.include_router(sla.router)


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "version": VERSION, "service": "shipfast-agent"}


if __name__ == "__main__":
    uvicorn.run("main:app", host=HOST, port=PORT, reload=False)
