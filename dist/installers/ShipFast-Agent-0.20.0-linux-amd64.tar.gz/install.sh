#!/bin/bash
# shipfast-agent/install.sh — 远程 Agent 一键安装脚本
set -euo pipefail

INSTALL_DIR="${SHIPFAST_INSTALL_DIR:-/opt/shipfast-agent}"
DATA_DIR="${SHIPFAST_DATA_DIR:-/var/lib/shipfast}"
SERVICE_NAME="shipfast-agent"

echo "==> ShipFast Agent 安装程序"

# 检测 Docker
if ! command -v docker &>/dev/null; then
  echo "==> 安装 Docker..."
  curl -fsSL https://get.docker.com | sh
  systemctl enable docker
  systemctl start docker
fi

# 检测 Python
if ! command -v python3 &>/dev/null; then
  echo "错误: 需要 Python 3.11+"
  exit 1
fi

# 创建目录
mkdir -p "$INSTALL_DIR" "$DATA_DIR"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp -r "$SCRIPT_DIR"/* "$INSTALL_DIR/" 2>/dev/null || true

# 安装依赖
pip3 install -r "$INSTALL_DIR/requirements.txt"

# 生成 Token
if [ ! -f "$DATA_DIR/agent.token" ]; then
  TOKEN=$(python3 -c "import secrets; print(secrets.token_urlsafe(32))")
  echo "$TOKEN" > "$DATA_DIR/agent.token"
  chmod 600 "$DATA_DIR/agent.token"
else
  TOKEN=$(cat "$DATA_DIR/agent.token")
fi

# systemd 服务
cat > "/etc/systemd/system/${SERVICE_NAME}.service" <<EOF
[Unit]
Description=ShipFast Agent
After=network.target docker.service
Requires=docker.service

[Service]
Type=simple
User=root
WorkingDirectory=${INSTALL_DIR}
Environment=SHIPFAST_DATA_DIR=${DATA_DIR}
Environment=SHIPFAST_AGENT_TOKEN=${TOKEN}
ExecStart=/usr/bin/python3 ${INSTALL_DIR}/main.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable "$SERVICE_NAME"
systemctl restart "$SERVICE_NAME"

echo ""
echo "✓ ShipFast Agent 安装完成"
echo "  地址: https://$(hostname -I | awk '{print $1}'):8443"
echo "  Token: ${TOKEN}"
echo ""
echo "在本地运行: shipfast server add"
echo "  别名: default"
echo "  主机: <服务器IP>"
echo "  端口: 8443"
echo "  Token: ${TOKEN}"
