"""shipfast-agent/routers/sla.py — SLA API"""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends

from routers.auth import verify_token
from services.sla_service import SLAService

router = APIRouter(prefix="/api/v1", tags=["sla"])


@router.get("/projects/{name}/sla")
async def project_sla(name: str, hours: int = 24, _: str = Depends(verify_token)) -> dict[str, Any]:
    return SLAService().status(name, hours)


@router.get("/sla/report")
async def sla_report(hours: int = 24, _: str = Depends(verify_token)) -> list[dict[str, Any]]:
    return SLAService().report(hours)
