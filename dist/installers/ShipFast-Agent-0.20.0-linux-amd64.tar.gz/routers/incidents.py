"""shipfast-agent/routers/incidents.py — 故障 API"""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends

from routers.auth import verify_token
from services.incident_service import IncidentService

router = APIRouter(prefix="/api/v1", tags=["incidents"])


@router.get("/incidents")
async def list_incidents(limit: int = 50, status: str = "", _: str = Depends(verify_token)) -> list[dict[str, Any]]:
    return IncidentService().list_incidents(limit, status)


@router.get("/incidents/{incident_id}")
async def get_incident(incident_id: str, _: str = Depends(verify_token)) -> dict[str, Any]:
    return IncidentService().get(incident_id)


@router.post("/incidents/{incident_id}/ack")
async def ack_incident(incident_id: str, _: str = Depends(verify_token)) -> dict[str, Any]:
    return IncidentService().ack(incident_id)


@router.post("/incidents/{incident_id}/resolve")
async def resolve_incident(incident_id: str, _: str = Depends(verify_token)) -> dict[str, Any]:
    return IncidentService().resolve(incident_id)
