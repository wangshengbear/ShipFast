"""shipfast-agent/routers/auth.py — Bearer Token 认证"""
from __future__ import annotations

import secrets

from fastapi import Depends, HTTPException, Security
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from config import AGENT_TOKEN

security = HTTPBearer()


async def verify_token(
    credentials: HTTPAuthorizationCredentials = Security(security),
) -> str:
    if not secrets.compare_digest(credentials.credentials, AGENT_TOKEN):
        raise HTTPException(status_code=401, detail="Invalid or missing token")
    return credentials.credentials
