"""shipfast-agent/routers/projects.py — 项目管理 API"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Depends, Header, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from models import DeployHistoryModel, ProjectModel
from routers.auth import verify_token
from services.docker_service import DockerService
from services.deploy_proof_service import verify_deploy_token
from services.log_service import stream_container_logs
from services.nginx_service import NginxService

router = APIRouter(prefix="/api/v1", tags=["projects"])


class RollbackRequest(BaseModel):
    version: str = ""


def _format_uptime(created_at: str) -> str:
    try:
        start = datetime.fromisoformat(created_at)
        delta = datetime.now(timezone.utc) - start.replace(tzinfo=timezone.utc)
        days = delta.days
        hours, rem = divmod(delta.seconds, 3600)
        minutes, _ = divmod(rem, 60)
        if days > 0:
            return f"{days}d {hours}h"
        if hours > 0:
            return f"{hours}h {minutes}m"
        return f"{minutes}m"
    except Exception:
        return "-"


@router.get("/projects")
async def list_projects(_: str = Depends(verify_token)) -> list[dict[str, Any]]:
    """获取所有项目列表"""
    projects = ProjectModel.list_all()
    result = []
    for p in projects:
        history = DeployHistoryModel.list_for_project(p["name"], limit=1)
        version = history[0]["version"] if history else ""
        result.append({
            "name": p["name"],
            "status": p["status"],
            "health_status": p.get("health_status") or "unknown",
            "environment": p.get("environment") or "",
            "url": p["url"] or "",
            "uptime": _format_uptime(p["created_at"]),
            "type": p["type"],
            "version": version,
        })
    return result


@router.get("/projects/{name}")
async def get_project(name: str, _: str = Depends(verify_token)) -> dict[str, Any]:
    """获取项目详情"""
    project = ProjectModel.get(name)
    if not project:
        raise HTTPException(status_code=404, detail=f"项目 {name} 不存在")

    docker = DockerService()
    container_stats = docker.get_container_stats(name)
    container_stats["health_status"] = project.get("health_status") or "unknown"
    history = DeployHistoryModel.list_for_project(name)

    config = json.loads(project["config_json"])
    return {
        "name": project["name"],
        "status": project["status"],
        "health_status": project.get("health_status") or "unknown",
        "environment": project.get("environment") or "",
        "url": project["url"],
        "type": project["type"],
        "version": history[0]["version"] if history else "",
        "config": config,
        "container": container_stats,
        "resources": {
            "cpu_limit": config.get("resources", {}).get("cpu", 1.0),
            "memory_mb": config.get("resources", {}).get("memory", 512),
        },
        "deploy_history": history,
    }


@router.post("/projects/{name}/restart")
async def restart_project(name: str, _: str = Depends(verify_token)) -> dict[str, str]:
    if not ProjectModel.get(name):
        raise HTTPException(status_code=404, detail=f"项目 {name} 不存在")
    DockerService().restart_container(name)
    ProjectModel.update_status(name, "running")
    return {"message": f"已重启 {name}"}


@router.post("/projects/{name}/stop")
async def stop_project(name: str, _: str = Depends(verify_token)) -> dict[str, str]:
    if not ProjectModel.get(name):
        raise HTTPException(status_code=404, detail=f"项目 {name} 不存在")
    DockerService().stop_container(name)
    ProjectModel.update_status(name, "stopped")
    return {"message": f"已停止 {name}"}


@router.post("/projects/{name}/start")
async def start_project(name: str, _: str = Depends(verify_token)) -> dict[str, str]:
    if not ProjectModel.get(name):
        raise HTTPException(status_code=404, detail=f"项目 {name} 不存在")
    DockerService().start_container(name)
    ProjectModel.update_status(name, "running")
    return {"message": f"已启动 {name}"}


@router.delete("/projects/{name}")
async def delete_project(name: str, _: str = Depends(verify_token)) -> dict[str, str]:
    project = ProjectModel.get(name)
    if not project:
        raise HTTPException(status_code=404, detail=f"项目 {name} 不存在")
    DockerService().remove_container_and_image(name, project.get("image_tag") or "")
    NginxService().remove_config(name)
    ProjectModel.delete(name)
    return {"message": f"已删除 {name}"}


@router.post("/projects/{name}/rollback")
async def rollback_project(
    name: str,
    body: RollbackRequest,
    _: str = Depends(verify_token),
    deploy_token: str | None = Header(default=None, alias="X-ShipFast-Deploy-Token"),
) -> dict[str, str]:
    verify_deploy_token(deploy_token, 1)
    from services.deploy_service import DeployService

    try:
        DeployService().rollback(name, body.version or None)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"message": f"已回滚 {name}"}


@router.get("/projects/{name}/k8s/status")
async def k8s_status(name: str, _: str = Depends(verify_token)) -> dict[str, Any]:
    from services.k8s_service import K8sService
    import json

    project = ProjectModel.get(name)
    if not project:
        raise HTTPException(status_code=404, detail=f"项目 {name} 不存在")
    config = json.loads(project["config_json"])
    k8s_cfg = config.get("kubernetes") or {}
    return K8sService().status(
        name,
        namespace=k8s_cfg.get("namespace") or "default",
        context=k8s_cfg.get("context") or "",
    )


@router.post("/projects/{name}/canary/promote")
async def promote_canary(
    name: str,
    _: str = Depends(verify_token),
    deploy_token: str | None = Header(default=None, alias="X-ShipFast-Deploy-Token"),
) -> dict[str, Any]:
    verify_deploy_token(deploy_token, 1)
    from services.deploy_service import DeployService

    try:
        return DeployService().promote_canary(name)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/projects/{name}/canary/abort")
async def abort_canary(
    name: str,
    _: str = Depends(verify_token),
    deploy_token: str | None = Header(default=None, alias="X-ShipFast-Deploy-Token"),
) -> dict[str, Any]:
    verify_deploy_token(deploy_token, 1)
    from services.deploy_service import DeployService

    try:
        return DeployService().abort_canary(name)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/projects/{name}/history")
async def project_history(
    name: str,
    limit: int = 10,
    _: str = Depends(verify_token),
) -> list[dict[str, Any]]:
    """获取部署历史"""
    if not ProjectModel.get(name):
        raise HTTPException(status_code=404, detail=f"项目 {name} 不存在")
    return DeployHistoryModel.list_for_project(name, limit=limit)


@router.get("/projects/{name}/logs")
async def project_logs(
    name: str,
    tail: int = 100,
    follow: bool = True,
    _: str = Depends(verify_token),
):
    """SSE 日志流"""
    if not ProjectModel.get(name):
        raise HTTPException(status_code=404, detail=f"项目 {name} 不存在")

    docker = DockerService()

    async def event_generator():
        async for line in stream_container_logs(docker, name, tail=tail, follow=follow):
            if line == "[DONE]":
                yield "data: [DONE]\n\n"
                break
            yield f"data: {line}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
    )
