"""shipfast-agent/routers/prometheus.py — Prometheus 指标导出"""
from __future__ import annotations

import os

from fastapi import APIRouter, Depends, Request
from fastapi.responses import PlainTextResponse

from routers.auth import verify_token
from services.prometheus_service import render_prometheus

router = APIRouter(tags=["prometheus"])


def _public_metrics() -> bool:
    return os.getenv("SHIPFAST_PROMETHEUS_PUBLIC", "").lower() in ("1", "true", "yes")


async def _optional_auth(request: Request) -> str:
    if _public_metrics():
        return "public"
    auth = request.headers.get("Authorization", "")
    token = auth.removeprefix("Bearer ").strip()
    from config import AGENT_TOKEN
    if token != AGENT_TOKEN:
        from fastapi import HTTPException
        raise HTTPException(status_code=401, detail="Unauthorized")
    return token


@router.get("/metrics/prometheus")
async def prometheus_metrics(_: str = Depends(_optional_auth)) -> PlainTextResponse:
    """Prometheus 文本格式指标（设置 SHIPFAST_PROMETHEUS_PUBLIC=1 可免认证）"""
    return PlainTextResponse(render_prometheus(), media_type="text/plain; version=0.0.4")
