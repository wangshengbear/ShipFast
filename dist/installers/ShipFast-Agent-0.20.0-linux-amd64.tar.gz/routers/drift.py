"""shipfast-agent/routers/drift.py — 漂移 API"""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Query

from routers.auth import verify_token
from services.drift_service import DriftService

router = APIRouter(prefix="/api/v1", tags=["drift"])


@router.get("/projects/{name}/drift")
async def drift_status(name: str, _: str = Depends(verify_token)) -> dict[str, Any]:
    return DriftService().status(name)


@router.post("/drift/check")
async def drift_check(
    project: str = "",
    fix: bool = Query(False),
    _: str = Depends(verify_token),
) -> dict[str, Any]:
    return DriftService().check_all(project or None, fix=fix)
