"""shipfast-agent/routers/alerts.py — 告警 API"""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends

from routers.auth import verify_token
from services.alert_service import AlertService

router = APIRouter(prefix="/api/v1", tags=["alerts"])


@router.get("/alerts")
async def list_alerts(limit: int = 50, _: str = Depends(verify_token)) -> list[dict[str, Any]]:
    return AlertService().list_active(limit)


@router.post("/alerts/check")
async def check_alerts(_: str = Depends(verify_token)) -> dict[str, Any]:
    fired = AlertService().evaluate_all()
    return {"checked_at": __import__("datetime").datetime.utcnow().isoformat() + "Z", "fired": fired, "count": len(fired)}
