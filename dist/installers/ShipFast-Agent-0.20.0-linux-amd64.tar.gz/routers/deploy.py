"""shipfast-agent/routers/deploy.py — 部署 API"""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Header
from pydantic import BaseModel, Field

from routers.auth import verify_token
from services.deploy_service import DeployService
from services.deploy_proof_service import verify_deploy_token

router = APIRouter(prefix="/api/v1", tags=["deploy"])


class BuildConfig(BaseModel):
    command: str = ""
    dockerfile: str = ""


class RunConfig(BaseModel):
    command: str = ""
    port: int = 8080
    replicas: int = 1


class DomainConfig(BaseModel):
    primary: str = ""
    aliases: list[str] = Field(default_factory=list)
    ssl: str = "auto"


class ResourceConfig(BaseModel):
    cpu: float = 1.0
    memory: int = 512


class HealthCheckConfig(BaseModel):
    path: str = "/health"
    interval: int = 30
    timeout: int = 60
    expected_status: int = 200


class RollbackConfig(BaseModel):
    auto_on_health_fail: bool = True


class BlueGreenConfig(BaseModel):
    port_offset: int = 1000


class CanaryConfig(BaseModel):
    percent: int = 10
    port_offset: int = 1001
    promote_after: int = 0


class StrategyConfig(BaseModel):
    type: str = "rolling"
    blue_green: BlueGreenConfig = Field(default_factory=BlueGreenConfig)
    canary: CanaryConfig = Field(default_factory=CanaryConfig)


class KubernetesConfig(BaseModel):
    enabled: bool = False
    cluster: str = ""
    clusters: dict[str, dict[str, Any]] = Field(default_factory=dict)
    namespace: str = "default"
    context: str = ""
    replicas: int = 1
    manifest: str = ""


class AlertRule(BaseModel):
    name: str = ""
    condition: str = ""
    when: str = ""
    severity: str = "warning"
    cooldown: int = 300
    notify: bool = True


class NotificationsConfig(BaseModel):
    webhook: str = ""
    slack_webhook: str = ""
    on_success: bool = True
    on_failure: bool = True


class DeployRequest(BaseModel):
    name: str
    type: str = "docker"
    git: str = ""
    branch: str = "main"
    tag: str = ""
    environment: str = ""
    build: BuildConfig = Field(default_factory=BuildConfig)
    run: RunConfig = Field(default_factory=RunConfig)
    env: dict[str, str] = Field(default_factory=dict)
    domain: DomainConfig = Field(default_factory=DomainConfig)
    resources: ResourceConfig = Field(default_factory=ResourceConfig)
    health_check: HealthCheckConfig = Field(default_factory=HealthCheckConfig)
    notifications: NotificationsConfig = Field(default_factory=NotificationsConfig)
    rollback: RollbackConfig = Field(default_factory=RollbackConfig)
    strategy: StrategyConfig = Field(default_factory=StrategyConfig)
    kubernetes: KubernetesConfig = Field(default_factory=KubernetesConfig)
    alerts: list[AlertRule] = Field(default_factory=list)


@router.post("/deploy")
async def deploy(
    req: DeployRequest,
    _: str = Depends(verify_token),
    deploy_token: str | None = Header(default=None, alias="X-ShipFast-Deploy-Token"),
) -> dict[str, Any]:
    """触发项目部署"""
    verify_deploy_token(deploy_token, 1)
    service = DeployService()
    return service.deploy(req.model_dump())
