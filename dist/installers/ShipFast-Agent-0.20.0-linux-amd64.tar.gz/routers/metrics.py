"""shipfast-agent/routers/metrics.py — 服务器与部署指标"""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends

from config import VERSION
from models import DeployHistoryModel, ProjectModel
from routers.auth import verify_token
from services.docker_service import DockerService, get_system_stats

router = APIRouter(prefix="/api/v1", tags=["metrics"])


@router.get("/metrics")
async def metrics(_: str = Depends(verify_token)) -> dict[str, Any]:
    """返回 Agent 部署与系统指标"""
    projects = ProjectModel.list_all()
    running = sum(1 for p in projects if p.get("status") == "running")
    error = sum(1 for p in projects if p.get("status") == "error")
    docker = DockerService()
    return {
        "version": VERSION,
        "service": "shipfast-agent",
        "projects_total": len(projects),
        "projects_running": running,
        "projects_error": error,
        "deployments_total": DeployHistoryModel.count_all(),
        "docker_status": "running" if docker.is_available() else "simulated",
        "containers": docker.list_running_count(),
        "system": get_system_stats(),
    }
