"""shipfast-agent/routers/server.py — 服务器状态 API"""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends

from routers.auth import verify_token
from services.docker_service import DockerService, get_system_stats

router = APIRouter(prefix="/api/v1", tags=["server"])


@router.get("/server/status")
async def server_status(_: str = Depends(verify_token)) -> dict[str, Any]:
    """返回服务器资源使用情况"""
    stats = get_system_stats()
    docker = DockerService()
    return {
        "cpu": stats["cpu"],
        "memory": stats["memory"],
        "disk": stats["disk"],
        "containers": docker.list_running_count(),
        "docker_status": "running" if docker.is_available() else "simulated",
    }
