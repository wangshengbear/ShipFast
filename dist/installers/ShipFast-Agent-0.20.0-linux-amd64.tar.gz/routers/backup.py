"""shipfast-agent/routers/backup.py — 备份 API"""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends
from pydantic import BaseModel

from routers.auth import verify_token
from services.backup_service import BackupService

router = APIRouter(prefix="/api/v1", tags=["backup"])


class RestoreBody(BaseModel):
    data: str


@router.get("/backup/export")
async def backup_export(_: str = Depends(verify_token)) -> dict[str, Any]:
    return BackupService().export_archive()


@router.post("/backup/restore")
async def backup_restore(body: RestoreBody, _: str = Depends(verify_token)) -> dict[str, Any]:
    return BackupService().restore_archive(body.data)
