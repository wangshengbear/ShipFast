"""shipfast-agent/config.py — Agent 配置"""
from __future__ import annotations

import os
import secrets
from pathlib import Path

# 数据目录（Windows 开发环境使用用户目录）
_default_data = (
    Path.home() / ".shipfast" / "agent-data"
    if os.name == "nt"
    else Path("/var/lib/shipfast")
)
DATA_DIR = Path(os.getenv("SHIPFAST_DATA_DIR", str(_default_data)))
DATA_DIR.mkdir(parents=True, exist_ok=True)

DB_PATH = DATA_DIR / "shipfast.db"
PROJECTS_DIR = DATA_DIR / "projects"
PROJECTS_DIR.mkdir(parents=True, exist_ok=True)

# 认证 Token：环境变量优先，否则持久化或生成
TOKEN_FILE = DATA_DIR / "agent.token"


def get_token() -> str:
    """获取或生成 Agent Bearer Token"""
    env_token = os.getenv("SHIPFAST_AGENT_TOKEN")
    if env_token:
        return env_token
    if TOKEN_FILE.exists():
        return TOKEN_FILE.read_text().strip()
    token = secrets.token_urlsafe(32)
    TOKEN_FILE.write_text(token)
    TOKEN_FILE.chmod(0o600)
    return token


AGENT_TOKEN = get_token()
HOST = os.getenv("SHIPFAST_AGENT_HOST", "0.0.0.0")
PORT = int(os.getenv("SHIPFAST_AGENT_PORT", "8443"))

# Nginx 配置路径
NGINX_SITES_AVAILABLE = Path("/etc/nginx/sites-available")
NGINX_SITES_ENABLED = Path("/etc/nginx/sites-enabled")

# 保留的历史版本数
MAX_DEPLOY_HISTORY = 3

# Agent 版本（与 CLI 对齐）
VERSION = "0.20.0"
