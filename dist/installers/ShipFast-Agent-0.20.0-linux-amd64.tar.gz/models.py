"""shipfast-agent/models.py — SQLite 数据模型"""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Generator, Optional

from config import DB_PATH


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


@contextmanager
def get_db() -> Generator[sqlite3.Connection, None, None]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    """初始化数据库表"""
    with get_db() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                type TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'stopped',
                health_status TEXT NOT NULL DEFAULT 'unknown',
                environment TEXT NOT NULL DEFAULT '',
                url TEXT,
                config_json TEXT NOT NULL,
                container_id TEXT,
                image_tag TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS deploy_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_name TEXT NOT NULL,
                version TEXT NOT NULL,
                commit_hash TEXT,
                image_tag TEXT NOT NULL,
                environment TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL,
                FOREIGN KEY (project_name) REFERENCES projects(name)
            );

            CREATE TABLE IF NOT EXISTS alert_events (
                id TEXT PRIMARY KEY,
                project_name TEXT NOT NULL,
                rule_name TEXT NOT NULL,
                severity TEXT NOT NULL DEFAULT 'warning',
                message TEXT NOT NULL,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS health_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_name TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS incidents (
                id TEXT PRIMARY KEY,
                project_name TEXT NOT NULL,
                rule_name TEXT NOT NULL,
                severity TEXT NOT NULL DEFAULT 'warning',
                status TEXT NOT NULL DEFAULT 'open',
                message TEXT NOT NULL,
                actor TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            """
        )
        _migrate_columns(conn)


def _migrate_columns(conn: sqlite3.Connection) -> None:
    """Phase 2 列迁移"""
    cols = {row[1] for row in conn.execute("PRAGMA table_info(projects)").fetchall()}
    if "health_status" not in cols:
        conn.execute(
            "ALTER TABLE projects ADD COLUMN health_status TEXT NOT NULL DEFAULT 'unknown'"
        )
    if "environment" not in cols:
        conn.execute(
            "ALTER TABLE projects ADD COLUMN environment TEXT NOT NULL DEFAULT ''"
        )
    hist_cols = {row[1] for row in conn.execute("PRAGMA table_info(deploy_history)").fetchall()}
    if "environment" not in hist_cols:
        conn.execute(
            "ALTER TABLE deploy_history ADD COLUMN environment TEXT NOT NULL DEFAULT ''"
        )


class ProjectModel:
    """项目 CRUD"""

    @staticmethod
    def upsert(
        name: str,
        project_type: str,
        config: dict[str, Any],
        status: str = "running",
        url: str = "",
        container_id: str = "",
        image_tag: str = "",
        health_status: str = "unknown",
        environment: str = "",
    ) -> None:
        now = _utcnow()
        config_json = json.dumps(config, ensure_ascii=False)
        with get_db() as conn:
            existing = conn.execute(
                "SELECT id FROM projects WHERE name = ?", (name,)
            ).fetchone()
            if existing:
                conn.execute(
                    """
                    UPDATE projects SET type=?, status=?, health_status=?, environment=?,
                    url=?, config_json=?, container_id=?, image_tag=?, updated_at=?
                    WHERE name=?
                    """,
                    (
                        project_type, status, health_status, environment,
                        url, config_json, container_id, image_tag, now, name,
                    ),
                )
            else:
                conn.execute(
                    """
                    INSERT INTO projects (name, type, status, health_status, environment,
                    url, config_json, container_id, image_tag, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        name, project_type, status, health_status, environment,
                        url, config_json, container_id, image_tag, now, now,
                    ),
                )

    @staticmethod
    def update_health(name: str, health_status: str) -> None:
        with get_db() as conn:
            conn.execute(
                "UPDATE projects SET health_status=?, updated_at=? WHERE name=?",
                (health_status, _utcnow(), name),
            )

    @staticmethod
    def get(name: str) -> Optional[dict[str, Any]]:
        with get_db() as conn:
            row = conn.execute("SELECT * FROM projects WHERE name = ?", (name,)).fetchone()
            if not row:
                return None
            return dict(row)

    @staticmethod
    def list_all() -> list[dict[str, Any]]:
        with get_db() as conn:
            rows = conn.execute("SELECT * FROM projects ORDER BY name").fetchall()
            return [dict(r) for r in rows]

    @staticmethod
    def update_status(name: str, status: str) -> None:
        with get_db() as conn:
            conn.execute(
                "UPDATE projects SET status=?, updated_at=? WHERE name=?",
                (status, _utcnow(), name),
            )

    @staticmethod
    def delete(name: str) -> None:
        with get_db() as conn:
            conn.execute("DELETE FROM projects WHERE name = ?", (name,))
            conn.execute("DELETE FROM deploy_history WHERE project_name = ?", (name,))

    @staticmethod
    def get_config(name: str) -> dict[str, Any]:
        project = ProjectModel.get(name)
        if not project:
            return {}
        return json.loads(project["config_json"])


class DeployHistoryModel:
    """部署历史"""

    @staticmethod
    def count_all() -> int:
        with get_db() as conn:
            row = conn.execute("SELECT COUNT(*) AS c FROM deploy_history").fetchone()
            return int(row["c"]) if row else 0

    @staticmethod
    def add(
        project_name: str,
        version: str,
        image_tag: str,
        commit_hash: str = "",
        environment: str = "",
    ) -> None:
        with get_db() as conn:
            conn.execute(
                """
                INSERT INTO deploy_history (project_name, version, commit_hash, image_tag, environment, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (project_name, version, commit_hash, image_tag, environment, _utcnow()),
            )

    @staticmethod
    def list_for_project(project_name: str, limit: int = 10) -> list[dict[str, Any]]:
        with get_db() as conn:
            rows = conn.execute(
                """
                SELECT version, commit_hash AS "commit", image_tag, environment, created_at
                FROM deploy_history WHERE project_name = ?
                ORDER BY id DESC LIMIT ?
                """,
                (project_name, limit),
            ).fetchall()
            return [dict(r) for r in rows]

    @staticmethod
    def get_version(project_name: str, version: str) -> Optional[dict[str, Any]]:
        with get_db() as conn:
            row = conn.execute(
                """
                SELECT * FROM deploy_history
                WHERE project_name = ? AND version = ?
                ORDER BY id DESC LIMIT 1
                """,
                (project_name, version),
            ).fetchone()
            return dict(row) if row else None

    @staticmethod
    def get_latest(project_name: str) -> Optional[dict[str, Any]]:
        with get_db() as conn:
            row = conn.execute(
                """
                SELECT * FROM deploy_history WHERE project_name = ?
                ORDER BY id DESC LIMIT 1
                """,
                (project_name,),
            ).fetchone()
            return dict(row) if row else None

    @staticmethod
    def get_previous(project_name: str) -> Optional[dict[str, Any]]:
        with get_db() as conn:
            rows = conn.execute(
                """
                SELECT * FROM deploy_history WHERE project_name = ?
                ORDER BY id DESC LIMIT 2
                """,
                (project_name,),
            ).fetchall()
            if len(rows) < 2:
                return None
            return dict(rows[1])

    @staticmethod
    def cleanup_old(project_name: str, keep: int = 3) -> None:
        with get_db() as conn:
            rows = conn.execute(
                """
                SELECT id FROM deploy_history WHERE project_name = ?
                ORDER BY id DESC
                """,
                (project_name,),
            ).fetchall()
            if len(rows) <= keep:
                return
            old_ids = [r["id"] for r in rows[keep:]]
            placeholders = ",".join("?" * len(old_ids))
            conn.execute(
                f"DELETE FROM deploy_history WHERE id IN ({placeholders})", old_ids
            )


class AlertModel:
    """告警事件"""

    @staticmethod
    def fire(project_name: str, rule_name: str, severity: str, message: str) -> dict[str, Any]:
        import uuid
        alert_id = "alrt-" + uuid.uuid4().hex[:12]
        now = _utcnow()
        with get_db() as conn:
            conn.execute(
                """
                INSERT INTO alert_events (id, project_name, rule_name, severity, message, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (alert_id, project_name, rule_name, severity, message, now),
            )
        return {
            "id": alert_id,
            "project_name": project_name,
            "rule_name": rule_name,
            "severity": severity,
            "message": message,
            "created_at": now,
        }

    @staticmethod
    def recently_fired(project_name: str, rule_name: str, cooldown_sec: int = 300) -> bool:
        with get_db() as conn:
            row = conn.execute(
                """
                SELECT created_at FROM alert_events
                WHERE project_name = ? AND rule_name = ?
                ORDER BY created_at DESC LIMIT 1
                """,
                (project_name, rule_name),
            ).fetchone()
            if not row:
                return False
            try:
                ts = datetime.fromisoformat(row["created_at"].replace("Z", "+00:00"))
                if ts.tzinfo is None:
                    ts = ts.replace(tzinfo=timezone.utc)
                return (datetime.now(timezone.utc) - ts).total_seconds() < cooldown_sec
            except Exception:
                return False

    @staticmethod
    def list_recent(limit: int = 50) -> list[dict[str, Any]]:
        with get_db() as conn:
            rows = conn.execute(
                """
                SELECT id, project_name, rule_name, severity, message, created_at
                FROM alert_events ORDER BY created_at DESC LIMIT ?
                """,
                (limit,),
            ).fetchall()
            return [dict(r) for r in rows]


class HealthEventModel:
    """健康检查事件（SLA）"""

    @staticmethod
    def record(project_name: str, status: str) -> None:
        with get_db() as conn:
            conn.execute(
                "INSERT INTO health_events (project_name, status, created_at) VALUES (?, ?, ?)",
                (project_name, status, _utcnow()),
            )

    @staticmethod
    def list_since(project_name: str, since_iso: str) -> list[dict[str, Any]]:
        with get_db() as conn:
            rows = conn.execute(
                """
                SELECT project_name, status, created_at FROM health_events
                WHERE project_name = ? AND created_at >= ?
                ORDER BY created_at ASC
                """,
                (project_name, since_iso),
            ).fetchall()
            return [dict(r) for r in rows]


class IncidentModel:
    """故障 / 事件跟踪"""

    @staticmethod
    def _new_id() -> str:
        import secrets
        return "inc-" + secrets.token_hex(4)

    @staticmethod
    def create(project_name: str, rule_name: str, severity: str, message: str) -> dict[str, Any]:
        iid = IncidentModel._new_id()
        now = _utcnow()
        with get_db() as conn:
            conn.execute(
                """
                INSERT INTO incidents (id, project_name, rule_name, severity, status, message, actor, created_at, updated_at)
                VALUES (?, ?, ?, ?, 'open', ?, '', ?, ?)
                """,
                (iid, project_name, rule_name, severity, message, now, now),
            )
        return IncidentModel.get(iid) or {}

    @staticmethod
    def get(incident_id: str) -> Optional[dict[str, Any]]:
        with get_db() as conn:
            row = conn.execute("SELECT * FROM incidents WHERE id = ?", (incident_id,)).fetchone()
            return dict(row) if row else None

    @staticmethod
    def find_open(project_name: str, rule_name: str) -> Optional[dict[str, Any]]:
        with get_db() as conn:
            row = conn.execute(
                """
                SELECT * FROM incidents WHERE project_name = ? AND rule_name = ? AND status = 'open'
                ORDER BY created_at DESC LIMIT 1
                """,
                (project_name, rule_name),
            ).fetchone()
            return dict(row) if row else None

    @staticmethod
    def touch(incident_id: str, message: str) -> dict[str, Any]:
        now = _utcnow()
        with get_db() as conn:
            conn.execute(
                "UPDATE incidents SET message=?, updated_at=? WHERE id=?",
                (message, now, incident_id),
            )
        return IncidentModel.get(incident_id) or {}

    @staticmethod
    def update_status(incident_id: str, status: str, actor: str) -> dict[str, Any]:
        now = _utcnow()
        with get_db() as conn:
            conn.execute(
                "UPDATE incidents SET status=?, actor=?, updated_at=? WHERE id=?",
                (status, actor, now, incident_id),
            )
        return IncidentModel.get(incident_id) or {}

    @staticmethod
    def list_recent(limit: int = 50, status: str = "") -> list[dict[str, Any]]:
        with get_db() as conn:
            if status:
                rows = conn.execute(
                    "SELECT * FROM incidents WHERE status = ? ORDER BY updated_at DESC LIMIT ?",
                    (status, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM incidents ORDER BY updated_at DESC LIMIT ?",
                    (limit,),
                ).fetchall()
            return [dict(r) for r in rows]

    @staticmethod
    def list_open_for_project(project_name: str) -> list[dict[str, Any]]:
        with get_db() as conn:
            rows = conn.execute(
                "SELECT * FROM incidents WHERE project_name = ? AND status = 'open'",
                (project_name,),
            ).fetchall()
            return [dict(r) for r in rows]
