"""shipfast-agent/utils/analyzer.py — 项目类型检测与 Dockerfile 生成"""
from __future__ import annotations

from pathlib import Path


def detect_project_type(project_dir: Path) -> str:
    """检测项目类型"""
    checks = [
        ("package.json", "node"),
        ("requirements.txt", "python"),
        ("pyproject.toml", "python"),
        ("go.mod", "go"),
        ("pom.xml", "java"),
        ("Cargo.toml", "rust"),
        ("composer.json", "php"),
        ("Gemfile", "ruby"),
        ("Dockerfile", "docker"),
    ]
    for filename, project_type in checks:
        if (project_dir / filename).exists():
            return project_type
    if (project_dir / "index.html").exists():
        return "static"
    for ext in (".onnx", ".pt", ".h5"):
        if list(project_dir.rglob(f"*{ext}")):
            return "model"
    return "docker"


def generate_dockerfile(
    project_type: str,
    build_command: str = "",
    run_command: str = "",
    port: int = 8080,
) -> str:
    """根据项目类型自动生成 Dockerfile"""
    if project_type == "node":
        cmd = run_command or "node index.js"
        build = build_command or "npm install"
        return f"""FROM node:18-alpine
WORKDIR /app
COPY . .
RUN {build}
EXPOSE {port}
CMD ["sh", "-c", "{cmd}"]
"""
    if project_type == "python":
        cmd = run_command or "python main.py"
        return f"""FROM python:3.11-slim
WORKDIR /app
COPY . .
RUN pip install --no-cache-dir -r requirements.txt 2>/dev/null || pip install .
EXPOSE {port}
CMD ["sh", "-c", "{cmd}"]
"""
    if project_type == "go":
        return """FROM golang:1.21-alpine AS builder
WORKDIR /app
COPY . .
RUN go build -o app .

FROM alpine:latest
WORKDIR /app
COPY --from=builder /app/app .
EXPOSE 8080
CMD ["./app"]
"""
    if project_type == "static":
        return """FROM nginx:alpine
COPY . /usr/share/nginx/html
EXPOSE 80
"""
    if project_type == "model":
        return f"""FROM python:3.11-slim
WORKDIR /app
COPY . .
RUN pip install fastapi uvicorn onnxruntime torch 2>/dev/null || true
EXPOSE {port}
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "{port}"]
"""
    return """FROM alpine:latest
WORKDIR /app
COPY . .
CMD ["echo", "Configure Dockerfile for this project"]
"""
