﻿ShipFast Agent v0.20.0 (amd64)
================================

方式 1 — systemd（VPS 推荐）:
  tar -xzf ShipFast-Agent-0.20.0-linux-amd64.tar.gz
  cd shipfast-agent
  chmod +x install.sh
  sudo ./install.sh

方式 2 — Docker（从本包构建）:
  sudo ./install.sh --docker

方式 3 — Docker Compose:
  docker compose -f docker-compose.yml up -d

健康检查: curl http://127.0.0.1:8443/health
Token: /var/lib/shipfast/agent.token

依赖: Python 3.11+ / Docker · Linux amd64
