"""shipfast-agent/services/drift_service.py — 配置漂移检测"""
from __future__ import annotations

import hashlib
import json
import logging
from typing import Any

from models import ProjectModel
from services.deploy_service import DeployService

logger = logging.getLogger(__name__)


def _stable_hash(config: dict[str, Any]) -> str:
    keys = sorted(k for k in config if k not in ("strategy_state", "desired_state"))
    canonical = {k: config.get(k) for k in keys}
    raw = json.dumps(canonical, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


class DriftService:
    """比较期望配置与当前运行状态"""

    def status(self, name: str) -> dict[str, Any]:
        project = ProjectModel.get(name)
        if not project:
            raise ValueError(f"项目 {name} 不存在")
        config = ProjectModel.get_config(name)
        desired = config.get("desired_state") or {}
        current_hash = _stable_hash(config)
        expected_hash = desired.get("config_hash") or current_hash
        diffs: list[str] = []
        if expected_hash != current_hash:
            diffs.append(f"config_hash: {expected_hash} -> {current_hash}")
        if project.get("status") == "error":
            diffs.append("status: error")
        if project.get("health_status") == "unhealthy":
            diffs.append("health: unhealthy")
        k8s = config.get("kubernetes") or {}
        if k8s.get("enabled"):
            replicas = int(k8s.get("replicas") or 1)
            state = config.get("strategy_state") or {}
            ready = state.get("k8s_ready_replicas")
            if ready is not None and int(ready) != replicas:
                diffs.append(f"k8s replicas: want {replicas}, ready {ready}")
        return {
            "project": name,
            "drifted": len(diffs) > 0,
            "diffs": diffs,
            "desired_hash": expected_hash,
            "current_hash": current_hash,
            "commit": desired.get("commit_hash") or "",
        }

    def check_all(self, name: str | None = None, fix: bool = False) -> dict[str, Any]:
        names = [name] if name else [p["name"] for p in ProjectModel.list_all()]
        drifted = 0
        results = []
        for n in names:
            try:
                st = self.status(n)
            except ValueError:
                continue
            if st["drifted"]:
                drifted += 1
                if fix:
                    try:
                        config = ProjectModel.get_config(n)
                        DeployService().deploy({**config, "name": n})
                        st["fixed"] = True
                    except Exception as exc:
                        st["fixed"] = False
                        st["fix_error"] = str(exc)
            results.append(st)
        return {"checked": len(results), "drifted": drifted, "results": results}
