"""shipfast-agent/services/notify_service.py — 部署通知 (Webhook / Slack)"""
from __future__ import annotations

import json
import logging
import urllib.request
from typing import Any

logger = logging.getLogger(__name__)


class NotifyService:
    """发送部署结果通知"""

    def send(self, event: str, payload: dict[str, Any], channels: dict[str, Any]) -> None:
        if not channels:
            return
        message = self._format_message(event, payload)
        webhook = channels.get("webhook") or channels.get("url")
        if webhook:
            self._post_json(webhook, {
                "event": event,
                "project": payload.get("name"),
                "environment": payload.get("environment"),
                "url": payload.get("url"),
                "version": payload.get("version"),
                "message": message,
                "success": payload.get("success"),
            })
        slack_url = channels.get("slack_webhook")
        if slack_url:
            color = "good" if payload.get("success") else "danger"
            self._post_json(slack_url, {
                "attachments": [{
                    "color": color,
                    "title": f"ShipFast: {event}",
                    "text": message,
                    "fields": [
                        {"title": "Project", "value": payload.get("name", ""), "short": True},
                        {"title": "Env", "value": payload.get("environment", ""), "short": True},
                    ],
                }]
            })

    def _format_message(self, event: str, payload: dict[str, Any]) -> str:
        name = payload.get("name", "")
        if event == "deploy.success":
            return f"✓ {name} 部署成功 → {payload.get('url')}"
        if event == "deploy.failed":
            return f"✗ {name} 部署失败: {payload.get('message')}"
        if event == "deploy.rollback":
            return f"↩ {name} 健康检查失败，已自动回滚"
        if event == "alert.fired":
            return f"⚠ 告警: {payload.get('message', name)}"
        return f"{event}: {name}"

    def _post_json(self, url: str, body: dict[str, Any]) -> None:
        try:
            data = json.dumps(body).encode("utf-8")
            req = urllib.request.Request(
                url, data=data,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                _ = resp.read()
        except Exception as exc:
            logger.warning("通知发送失败: %s", exc)
