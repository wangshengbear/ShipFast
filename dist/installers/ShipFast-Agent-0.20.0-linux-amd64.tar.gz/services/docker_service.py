"""shipfast-agent/services/docker_service.py — Docker SDK 封装"""
from __future__ import annotations

import logging
import subprocess
import time
from typing import Any, Optional

logger = logging.getLogger(__name__)

try:
    import docker
    from docker.errors import DockerException, NotFound

    DOCKER_AVAILABLE = True
except ImportError:
    DOCKER_AVAILABLE = False
    docker = None  # type: ignore
    DockerException = Exception  # type: ignore
    NotFound = Exception  # type: ignore


class DockerService:
    """Docker 操作封装，无 Docker 环境时降级为模拟模式"""

    def __init__(self) -> None:
        self.client: Any = None
        self.simulated = False
        if DOCKER_AVAILABLE:
            try:
                self.client = docker.from_env()
                self.client.ping()
            except Exception as exc:
                logger.warning("Docker 不可用，使用模拟模式: %s", exc)
                self.simulated = True
        else:
            self.simulated = True

    def build_image(self, path: str, tag: str, dockerfile: str = "Dockerfile") -> str:
        """构建 Docker 镜像"""
        if self.simulated:
            logger.info("[模拟] 构建镜像 %s", tag)
            return tag
        assert self.client is not None
        image, logs = self.client.images.build(path=path, tag=tag, dockerfile=dockerfile, rm=True)
        for chunk in logs:
            if "stream" in chunk:
                logger.info(chunk["stream"].strip())
        return image.tags[0] if image.tags else tag

    def run_container(
        self,
        image: str,
        name: str,
        port: int,
        env: Optional[dict[str, str]] = None,
        cpu: float = 1.0,
        memory_mb: int = 512,
    ) -> str:
        """启动容器并返回 container_id"""
        if self.simulated:
            fake_id = f"sim-{name}-{int(time.time())}"
            logger.info("[模拟] 启动容器 %s -> %s", name, fake_id)
            return fake_id

        assert self.client is not None
        # 停止并移除同名容器
        try:
            old = self.client.containers.get(name)
            old.stop(timeout=10)
            old.remove(force=True)
        except NotFound:
            pass

        nano_cpus = int(cpu * 1e9)
        container = self.client.containers.run(
            image,
            name=name,
            detach=True,
            ports={f"{port}/tcp": port},
            environment=env or {},
            nano_cpus=nano_cpus,
            mem_limit=f"{memory_mb}m",
            restart_policy={"Name": "unless-stopped"},
        )
        return container.id

    def stop_container(self, name: str) -> None:
        if self.simulated:
            logger.info("[模拟] 停止容器 %s", name)
            return
        assert self.client is not None
        try:
            c = self.client.containers.get(name)
            c.stop(timeout=10)
        except NotFound:
            pass

    def start_container(self, name: str) -> None:
        if self.simulated:
            logger.info("[模拟] 启动容器 %s", name)
            return
        assert self.client is not None
        c = self.client.containers.get(name)
        c.start()

    def restart_container(self, name: str) -> None:
        if self.simulated:
            logger.info("[模拟] 重启容器 %s", name)
            return
        assert self.client is not None
        try:
            c = self.client.containers.get(name)
            c.restart(timeout=10)
        except NotFound:
            raise ValueError(f"容器 {name} 不存在")

    def remove_container_and_image(self, name: str, image_tag: str = "") -> None:
        if self.simulated:
            logger.info("[模拟] 删除容器和镜像 %s", name)
            return
        assert self.client is not None
        try:
            c = self.client.containers.get(name)
            c.stop(timeout=10)
            c.remove(force=True)
        except NotFound:
            pass
        if image_tag:
            try:
                self.client.images.remove(image_tag, force=True)
            except DockerException:
                pass

    def get_container_stats(self, name: str) -> dict[str, Any]:
        if self.simulated:
            return {"cpu_percent": 0.0, "memory_mb": 0.0, "status": "running"}
        assert self.client is not None
        try:
            c = self.client.containers.get(name)
            stats = c.stats(stream=False)
            return {
                "status": c.status,
                "id": c.short_id,
                "image": c.image.tags[0] if c.image.tags else "",
            }
        except NotFound:
            return {"status": "not_found"}

    def get_logs(self, name: str, tail: int = 100) -> str:
        if self.simulated:
            return f"[模拟日志] 容器 {name} 运行中...\n"
        assert self.client is not None
        try:
            c = self.client.containers.get(name)
            return c.logs(tail=tail).decode("utf-8", errors="replace")
        except NotFound:
            return f"容器 {name} 不存在\n"

    def list_running_count(self) -> int:
        if self.simulated:
            return 0
        assert self.client is not None
        return len(self.client.containers.list())

    def is_available(self) -> bool:
        return not self.simulated


def get_system_stats() -> dict[str, float]:
    """获取服务器 CPU/内存/磁盘使用率"""
    try:
        import psutil

        return {
            "cpu": psutil.cpu_percent(interval=0.5),
            "memory": psutil.virtual_memory().percent,
            "disk": psutil.disk_usage("/").percent,
        }
    except ImportError:
        # 无 psutil 时用 subprocess 估算
        try:
            if subprocess.os.name != "nt":  # type: ignore
                load = subprocess.check_output(["uptime"]).decode()
                return {"cpu": 10.0, "memory": 30.0, "disk": 50.0}
        except Exception:
            pass
        return {"cpu": 0.0, "memory": 0.0, "disk": 0.0}
