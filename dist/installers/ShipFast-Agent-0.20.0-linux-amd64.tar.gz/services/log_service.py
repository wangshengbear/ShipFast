"""shipfast-agent/services/log_service.py — 日志 SSE 流推送"""
from __future__ import annotations

import asyncio
import time
from typing import AsyncGenerator

from services.docker_service import DockerService


async def stream_container_logs(
    docker: DockerService,
    container_name: str,
    tail: int = 100,
    follow: bool = True,
) -> AsyncGenerator[str, None]:
    """SSE 格式流式推送容器日志"""
    # 先发送历史日志
    logs = docker.get_logs(container_name, tail=tail)
    for line in logs.splitlines():
        yield line

    if not follow:
        yield "[DONE]"
        return

    # 持续跟踪（模拟模式轮询）
    last_len = len(logs)
    for _ in range(120):  # 最多跟踪 10 分钟
        await asyncio.sleep(5)
        new_logs = docker.get_logs(container_name, tail=tail)
        if len(new_logs) > last_len:
            delta = new_logs[last_len:]
            for line in delta.splitlines():
                if line.strip():
                    yield line
            last_len = len(new_logs)
        elif docker.simulated:
            yield f"[{time.strftime('%H:%M:%S')}] heartbeat"
    yield "[DONE]"
