"""shipfast-agent/services/deploy_proof_service.py — 部署凭证校验（可选）"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import time

from fastapi import HTTPException


def _require_deploy_token() -> bool:
    return os.getenv("SHIPFAST_REQUIRE_DEPLOY_TOKEN", "").lower() in ("1", "true", "yes")


def _deploy_secret() -> bytes:
    secret = os.getenv("SHIPFAST_LICENSE_SECRET") or os.getenv("SHIPFAST_DEPLOY_TOKEN_SECRET", "")
    return secret.encode("utf-8")


def verify_deploy_token(token: str | None, server_count: int = 1) -> None:
    """校验 CLI/Web 携带的 Cloud 部署凭证。未启用 REQUIRE 时跳过。"""
    if not _require_deploy_token():
        return
    secret = _deploy_secret()
    if not secret:
        raise HTTPException(
            status_code=503,
            detail="Agent 已启用 SHIPFAST_REQUIRE_DEPLOY_TOKEN 但未配置 SHIPFAST_LICENSE_SECRET",
        )
    if not token:
        raise HTTPException(status_code=403, detail="缺少部署凭证 X-ShipFast-Deploy-Token")
    parts = token.split(".", 2)
    if len(parts) != 3 or parts[0] != "dt1":
        raise HTTPException(status_code=403, detail="部署凭证格式无效")
    payload_b64, sig = parts[1], parts[2]
    expected = base64.urlsafe_b64encode(
        hmac.new(secret, f"deploy:{payload_b64}".encode(), hashlib.sha256).digest()
    ).rstrip(b"=").decode()
    if not hmac.compare_digest(sig, expected):
        raise HTTPException(status_code=403, detail="部署凭证签名校验失败")
    try:
        raw = base64.urlsafe_b64decode(payload_b64 + "==")
        claims = json.loads(raw)
    except Exception as exc:
        raise HTTPException(status_code=403, detail="部署凭证 payload 无效") from exc
    if int(claims.get("exp", 0)) < int(time.time()):
        raise HTTPException(status_code=403, detail="部署凭证已过期")
    max_servers = int(claims.get("server_count") or 1)
    if server_count <= 0:
        server_count = 1
    if max_servers > 0 and server_count > max_servers:
        raise HTTPException(status_code=403, detail="部署凭证服务器数量不匹配")
