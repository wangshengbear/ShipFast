"""shipfast-agent/services/nginx_service.py — Nginx 反向代理配置"""
from __future__ import annotations

import logging
import subprocess
from pathlib import Path

from config import NGINX_SITES_AVAILABLE, NGINX_SITES_ENABLED

logger = logging.getLogger(__name__)


class NginxService:
    """管理 Nginx 站点配置"""

    def __init__(self) -> None:
        self.available = NGINX_SITES_AVAILABLE
        self.enabled = NGINX_SITES_ENABLED

    def is_available(self) -> bool:
        return self.available.exists() and shutil_which("nginx")

    def configure_canary(
        self,
        name: str,
        domain: str,
        main_port: int,
        canary_port: int,
        percent: int,
        ssl_cert: str = "",
        ssl_key: str = "",
    ) -> None:
        """Nginx 按百分比分流 Canary 流量"""
        if not self.is_available():
            logger.warning("Nginx 不可用，Canary 分流仅记录在元数据")
            return

        listen = f"listen 80;\n    server_name {domain};"
        if ssl_cert and ssl_key:
            listen = f"""listen 443 ssl;
    server_name {domain};
    ssl_certificate {ssl_cert};
    ssl_certificate_key {ssl_key};"""

        config = f"""# ShipFast canary: {name} ({percent}%)
split_clients "${{remote_addr}}${{date_gmt}}" $sf_backend {{
    {percent}% 127.0.0.1:{canary_port};
    *          127.0.0.1:{main_port};
}}

server {{
    {listen}

    location / {{
        proxy_pass http://$sf_backend;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }}
}}
"""
        conf_path = self.available / f"{name}.conf"
        conf_path.write_text(config)
        enabled_path = self.enabled / f"{name}.conf"
        if not enabled_path.exists():
            enabled_path.symlink_to(conf_path)
        self.reload()

    def configure_proxy(
        self,
        name: str,
        domain: str,
        port: int,
        ssl_cert: str = "",
        ssl_key: str = "",
    ) -> None:
        """为项目创建 Nginx 反向代理配置"""
        if not self.is_available():
            logger.warning("Nginx 不可用，跳过反代配置")
            return

        ssl_block = ""
        listen = f"listen 80;\n    server_name {domain};"
        if ssl_cert and ssl_key:
            listen = f"""listen 443 ssl;
    server_name {domain};
    ssl_certificate {ssl_cert};
    ssl_certificate_key {ssl_key};"""

        config = f"""# ShipFast managed: {name}
server {{
    {listen}

    location / {{
        proxy_pass http://127.0.0.1:{port};
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }}
}}
"""
        conf_path = self.available / f"{name}.conf"
        conf_path.write_text(config)
        enabled_path = self.enabled / f"{name}.conf"
        if not enabled_path.exists():
            enabled_path.symlink_to(conf_path)
        self.reload()

    def remove_config(self, name: str) -> None:
        if not self.is_available():
            return
        for path in (self.enabled / f"{name}.conf", self.available / f"{name}.conf"):
            if path.is_symlink():
                path.unlink()
            elif path.exists():
                path.unlink()
        self.reload()

    def reload(self) -> None:
        try:
            subprocess.run(["nginx", "-t"], check=True, capture_output=True)
            subprocess.run(["systemctl", "reload", "nginx"], check=False, capture_output=True)
        except (subprocess.CalledProcessError, FileNotFoundError) as exc:
            logger.warning("Nginx 重载失败: %s", exc)


def shutil_which(cmd: str) -> bool:
    from shutil import which
    return which(cmd) is not None
