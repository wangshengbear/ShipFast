"""shipfast-agent/services/health_service.py — 健康检查服务"""
from __future__ import annotations

import logging
import time
import urllib.error
import urllib.request
from typing import Any

logger = logging.getLogger(__name__)


class HealthService:
    """HTTP 健康检查"""

    def check(
        self,
        base_url: str,
        path: str = "/health",
        timeout: int = 60,
        interval: int = 3,
        expected_status: int = 200,
        simulated: bool = False,
    ) -> tuple[bool, str]:
        """
        轮询健康检查端点。
        返回 (是否健康, 状态描述)。
        """
        if simulated:
            return True, "healthy"

        check_url = base_url.rstrip("/") + path
        deadline = time.time() + timeout
        last_error = ""

        while time.time() < deadline:
            try:
                req = urllib.request.Request(check_url, method="GET")
                with urllib.request.urlopen(req, timeout=5) as resp:
                    if resp.status == expected_status:
                        return True, "healthy"
                    last_error = f"status {resp.status}"
            except urllib.error.HTTPError as exc:
                last_error = f"HTTP {exc.code}"
            except Exception as exc:
                last_error = str(exc)
            time.sleep(interval)

        logger.warning("健康检查失败 %s: %s", check_url, last_error)
        return False, "unhealthy"

    def probe_now(self, url: str, path: str, expected_status: int = 200) -> str:
        """单次探测，返回 healthy/unhealthy/unknown"""
        ok, status = self.check(
            url, path, timeout=10, interval=1, expected_status=expected_status
        )
        return status if ok else "unhealthy"


def health_from_config(config: dict[str, Any]) -> dict[str, Any]:
    """从部署配置提取健康检查参数"""
    health = config.get("health_check") or {}
    return {
        "path": health.get("path") or "/health",
        "timeout": int(health.get("timeout") or 60),
        "interval": int(health.get("interval") or 3),
        "expected_status": int(health.get("expected_status") or 200),
    }
