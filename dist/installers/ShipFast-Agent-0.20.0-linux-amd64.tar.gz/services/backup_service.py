"""shipfast-agent/services/backup_service.py — Agent 数据备份与恢复"""
from __future__ import annotations

import base64
import io
import json
import shutil
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from config import DB_PATH, PROJECTS_DIR, TOKEN_FILE, VERSION


class BackupService:
    """打包 SQLite、projects 目录与 token 元数据"""

    def export_archive(self) -> dict[str, Any]:
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            if DB_PATH.exists():
                zf.write(DB_PATH, "shipfast.db")
            if PROJECTS_DIR.exists():
                for path in PROJECTS_DIR.rglob("*"):
                    if path.is_file():
                        zf.write(path, str(Path("projects") / path.relative_to(PROJECTS_DIR)))
            manifest = {
                "version": VERSION,
                "exported_at": datetime.now(timezone.utc).isoformat(),
                "has_token": TOKEN_FILE.exists(),
            }
            zf.writestr("manifest.json", json.dumps(manifest, indent=2))
        data = buf.getvalue()
        return {
            "format": "zip",
            "size": len(data),
            "data": base64.b64encode(data).decode("ascii"),
            "manifest": manifest,
        }

    def restore_archive(self, b64_data: str) -> dict[str, Any]:
        raw = base64.b64decode(b64_data)
        buf = io.BytesIO(raw)
        with zipfile.ZipFile(buf, "r") as zf:
            names = zf.namelist()
            if "shipfast.db" in names:
                DB_PATH.parent.mkdir(parents=True, exist_ok=True)
                with open(DB_PATH, "wb") as out:
                    out.write(zf.read("shipfast.db"))
            if any(n.startswith("projects/") for n in names):
                if PROJECTS_DIR.exists():
                    shutil.rmtree(PROJECTS_DIR)
                PROJECTS_DIR.mkdir(parents=True, exist_ok=True)
                for name in names:
                    if name.startswith("projects/") and not name.endswith("/"):
                        target = PROJECTS_DIR / name[len("projects/") :]
                        target.parent.mkdir(parents=True, exist_ok=True)
                        target.write_bytes(zf.read(name))
        return {"message": "restore ok", "files": len(names)}
