"""shipfast-agent/services/prometheus_service.py — Prometheus 文本格式指标"""
from __future__ import annotations

from config import VERSION
from models import DeployHistoryModel, ProjectModel
from services.docker_service import DockerService, get_system_stats


def render_prometheus() -> str:
    projects = ProjectModel.list_all()
    running = sum(1 for p in projects if p.get("status") == "running")
    error = sum(1 for p in projects if p.get("status") == "error")
    stopped = sum(1 for p in projects if p.get("status") == "stopped")
    docker = DockerService()
    stats = get_system_stats()
    deployments = DeployHistoryModel.count_all()
    canary = sum(
        1 for p in projects
        if (ProjectModel.get_config(p["name"]).get("strategy_state") or {}).get("canary_active")
    )

    lines = [
        "# HELP shipfast_info ShipFast Agent version info",
        "# TYPE shipfast_info gauge",
        f'shipfast_info{{version="{VERSION}"}} 1',
        "# HELP shipfast_projects_total Total managed projects",
        "# TYPE shipfast_projects_total gauge",
        f"shipfast_projects_total {len(projects)}",
        "# HELP shipfast_projects_running Running projects",
        "# TYPE shipfast_projects_running gauge",
        f"shipfast_projects_running {running}",
        "# HELP shipfast_projects_error Error-state projects",
        "# TYPE shipfast_projects_error gauge",
        f"shipfast_projects_error {error}",
        "# HELP shipfast_projects_stopped Stopped projects",
        "# TYPE shipfast_projects_stopped gauge",
        f"shipfast_projects_stopped {stopped}",
        "# HELP shipfast_deployments_total Total deployment records",
        "# TYPE shipfast_deployments_total counter",
        f"shipfast_deployments_total {deployments}",
        "# HELP shipfast_canary_active Active canary deployments",
        "# TYPE shipfast_canary_active gauge",
        f"shipfast_canary_active {canary}",
        "# HELP shipfast_docker_up Docker daemon availability",
        "# TYPE shipfast_docker_up gauge",
        f"shipfast_docker_up {1 if docker.is_available() else 0}",
        "# HELP shipfast_containers_running Running containers",
        "# TYPE shipfast_containers_running gauge",
        f"shipfast_containers_running {docker.list_running_count()}",
        "# HELP shipfast_system_cpu_percent Host CPU usage percent",
        "# TYPE shipfast_system_cpu_percent gauge",
        f"shipfast_system_cpu_percent {stats.get('cpu', 0)}",
        "# HELP shipfast_system_memory_percent Host memory usage percent",
        "# TYPE shipfast_system_memory_percent gauge",
        f"shipfast_system_memory_percent {stats.get('memory', 0)}",
        "# HELP shipfast_system_disk_percent Host disk usage percent",
        "# TYPE shipfast_system_disk_percent gauge",
        f"shipfast_system_disk_percent {stats.get('disk', 0)}",
    ]
    return "\n".join(lines) + "\n"
