"""shipfast-agent/services/deploy_service.py — 部署核心逻辑"""
from __future__ import annotations

import logging
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any

from config import MAX_DEPLOY_HISTORY, PROJECTS_DIR
from models import DeployHistoryModel, ProjectModel
from services.docker_service import DockerService
from services.health_service import HealthService, health_from_config
from services.notify_service import NotifyService
from services.nginx_service import NginxService
from services.ssl_service import SSLService
from services.strategy_service import StrategyService
from utils.analyzer import detect_project_type, generate_dockerfile

logger = logging.getLogger(__name__)


class DeployService:
    """编排完整部署流程"""

    def __init__(self) -> None:
        self.docker = DockerService()
        self.nginx = NginxService()
        self.ssl = SSLService()
        self.health = HealthService()
        self.notify = NotifyService()
        self.strategy = StrategyService()

    def deploy(self, payload: dict[str, Any]) -> dict[str, Any]:
        name = payload["name"]
        project_type = payload.get("type") or "docker"
        branch = payload.get("branch") or "main"

        work_dir = PROJECTS_DIR / name
        if work_dir.exists():
            shutil.rmtree(work_dir)
        work_dir.mkdir(parents=True)

        # 1. 克隆 Git 或准备目录
        git_url = payload.get("git", "")
        if git_url:
            self._clone_repo(git_url, branch, work_dir)
            detected = detect_project_type(work_dir)
            if project_type == "docker":
                project_type = detected

        build_cfg = payload.get("build") or {}
        run_cfg = payload.get("run") or {}
        port = int(run_cfg.get("port") or 8080)
        run_command = run_cfg.get("command") or ""
        build_command = build_cfg.get("command") or ""

        # 2. 生成或使用 Dockerfile
        dockerfile_path = work_dir / "Dockerfile"
        custom_dockerfile = build_cfg.get("dockerfile")
        if custom_dockerfile and Path(custom_dockerfile).exists():
            shutil.copy(custom_dockerfile, dockerfile_path)
        elif not dockerfile_path.exists():
            dockerfile_path.write_text(
                generate_dockerfile(project_type, build_command, run_command, port)
            )

        # 3. 构建镜像
        version = payload.get("tag") or f"v{int(time.time())}"
        image_tag = f"shipfast/{name}:{version}"
        self.docker.build_image(str(work_dir), image_tag)

        # 4. 按策略 / K8s 启动
        env = payload.get("env") or {}
        resources = payload.get("resources") or {}
        k8s_cfg = payload.get("kubernetes") or {}
        use_k8s = bool(k8s_cfg.get("enabled"))

        strategy_cfg = payload.get("strategy") or {}
        strategy_type = strategy_cfg.get("type") or "rolling"
        existing = ProjectModel.get(name)
        has_existing = existing is not None and existing.get("status") in ("running", "error")
        strategy_meta: dict[str, Any] = {}
        container_id = ""

        if use_k8s:
            from services.k8s_service import K8sService, resolve_target
            k8s = K8sService()
            ns, ctx, replicas = resolve_target(k8s_cfg, run_cfg)
            k8s_result = k8s.deploy(
                name, image_tag, namespace=ns,
                context=ctx,
                replicas=replicas, port=port, env=env,
                manifest_path=k8s_cfg.get("manifest") or "",
            )
            k8s_result["cluster"] = k8s_cfg.get("cluster") or ""
            container_id = name
            strategy_type = "kubernetes"
            strategy_meta = k8s_result
        else:
            try:
                if strategy_type == "blue_green":
                    container_id, _, strategy_meta = self.strategy.deploy_blue_green(
                        name, image_tag, port, env, resources, payload,
                    )
                elif strategy_type == "canary":
                    container_id, _, strategy_meta = self.strategy.deploy_canary(
                        name, image_tag, port, env, resources, payload, has_existing,
                    )
                else:
                    container_id = self.strategy.deploy_rolling(
                        name, image_tag, port, env, resources,
                    )
            except ValueError as exc:
                return {
                    "success": False,
                    "url": "",
                    "message": str(exc),
                    "version": version,
                    "health_status": "unhealthy",
                    "auto_rollback": False,
                    "strategy": strategy_type,
                }

        # 5. Nginx + SSL
        domain_cfg = payload.get("domain") or {}
        primary_domain = domain_cfg.get("primary") or ""
        url = f"http://127.0.0.1:{port}"
        cert_path, key_path = "", ""

        canary_active = strategy_meta.get("canary_active", False)
        if primary_domain and not canary_active and not use_k8s:
            ssl_mode = domain_cfg.get("ssl", "")
            if ssl_mode == "auto":
                cert_path, key_path = self.ssl.request_certificate(primary_domain)
            self.nginx.configure_proxy(name, primary_domain, port, cert_path, key_path)
            scheme = "https" if cert_path else "http"
            url = f"{scheme}://{primary_domain}"
        elif primary_domain and canary_active and not use_k8s:
            ssl_mode = domain_cfg.get("ssl", "")
            if ssl_mode == "auto":
                cert_path, key_path = self.ssl.request_certificate(primary_domain)
            canary_port = int(strategy_meta.get("canary_port") or port + 1001)
            pct = int(strategy_meta.get("canary_percent") or 10)
            self.nginx.configure_canary(
                name, primary_domain, port, canary_port, pct, cert_path, key_path,
            )
            scheme = "https" if cert_path else "http"
            url = f"{scheme}://{primary_domain}"

        # 6. 健康检查（Canary 活跃时已在策略内检查候选版本）
        health_cfg = health_from_config(payload)
        if canary_active:
            healthy = True
            health_status = strategy_meta.get("health_status") or "healthy"
        elif strategy_type == "blue_green":
            healthy = True
            health_status = strategy_meta.get("health_status") or "healthy"
            if primary_domain and not use_k8s:
                healthy, health_status = self.health.check(
                    url, path=health_cfg["path"], timeout=health_cfg["timeout"],
                    interval=min(health_cfg["interval"], 10),
                    expected_status=health_cfg["expected_status"],
                    simulated=self.docker.simulated,
                )
        elif use_k8s:
            healthy = True
            health_status = "healthy"
        else:
            healthy, health_status = self.health.check(
                url,
                path=health_cfg["path"],
                timeout=health_cfg["timeout"],
                interval=min(health_cfg["interval"], 10),
                expected_status=health_cfg["expected_status"],
                simulated=self.docker.simulated,
            )
        status = "running" if healthy else "error"
        auto_rollback = False
        rolled_version = ""
        rolled_image = image_tag
        rollback_cfg = payload.get("rollback") or {}
        if not healthy:
            logger.warning("健康检查未通过，项目标记为 error")
            if rollback_cfg.get("auto_on_health_fail", True):
                try:
                    rolled = self.rollback(name, use_latest=True)
                    auto_rollback = True
                    status = "running"
                    health_status = "healthy"
                    rolled_version = rolled["version"]
                    rolled_image = rolled["image_tag"]
                    url = rolled.get("url") or url
                    logger.info("已自动回滚 %s 到 %s", name, rolled_version)
                except ValueError as exc:
                    logger.warning("自动回滚失败: %s", exc)

        # 7. 保存元数据
        commit_hash = self._get_commit_hash(work_dir) if git_url else ""
        environment = payload.get("environment") or ""
        config_snapshot = payload
        if strategy_meta:
            config_snapshot = {**payload, "strategy_state": strategy_meta}
        if use_k8s and k8s_cfg.get("alerts") is None and payload.get("alerts"):
            config_snapshot = {**config_snapshot, "alerts": payload.get("alerts")}
        from services.drift_service import _stable_hash
        config_snapshot = {
            **config_snapshot,
            "desired_state": {
                "config_hash": _stable_hash(payload),
                "commit_hash": commit_hash,
            },
        }
        final_version = rolled_version or version
        final_image = rolled_image if auto_rollback else image_tag
        if canary_active and not auto_rollback:
            final_image = existing.get("image_tag") or image_tag if existing else image_tag
        ProjectModel.upsert(
            name=name,
            project_type=project_type,
            config=config_snapshot,
            status=status,
            url=url,
            container_id=container_id,
            image_tag=final_image,
            health_status=health_status,
            environment=environment,
        )
        try:
            from models import HealthEventModel
            HealthEventModel.record(name, health_status)
        except Exception:
            pass
        if not auto_rollback:
            hist_version = version
            if canary_active:
                hist_version = f"{version}-canary"
            DeployHistoryModel.add(name, hist_version, image_tag, commit_hash, environment)
        DeployHistoryModel.cleanup_old(name, MAX_DEPLOY_HISTORY)

        result = {
            "success": status == "running",
            "url": url,
            "message": "部署完成" if status == "running" else "部署完成但健康检查失败",
            "version": final_version,
            "health_status": health_status,
            "auto_rollback": auto_rollback,
            "strategy": strategy_type,
        }
        if canary_active:
            result["canary_percent"] = strategy_meta.get("canary_percent")
            result["message"] = f"Canary 部署 {strategy_meta.get('canary_percent')}% 流量，运行 shipfast canary promote 全量发布"
        if auto_rollback:
            result["message"] = f"健康检查失败，已自动回滚到 {final_version}"

        notify_cfg = payload.get("notifications") or {}
        channels = {}
        if notify_cfg.get("webhook"):
            channels["webhook"] = notify_cfg["webhook"]
        if notify_cfg.get("slack_webhook"):
            channels["slack_webhook"] = notify_cfg["slack_webhook"]
        event = "deploy.success" if result["success"] else "deploy.failed"
        if auto_rollback:
            event = "deploy.rollback"
        if channels and (notify_cfg.get("on_success", True) or not result["success"]):
            self.notify.send(event, {**result, "name": name, "environment": environment}, channels)

        # 部署后评估告警
        try:
            from services.alert_service import AlertService
            AlertService().evaluate_project(name)
        except Exception as exc:
            logger.debug("告警评估跳过: %s", exc)

        return result

    def _clone_repo(self, git_url: str, branch: str, dest: Path) -> None:
        try:
            subprocess.run(
                ["git", "clone", "--depth", "1", "--branch", branch, git_url, str(dest)],
                check=True,
                capture_output=True,
                timeout=300,
            )
        except (subprocess.CalledProcessError, FileNotFoundError) as exc:
            logger.warning("Git 克隆失败: %s，创建占位目录", exc)
            (dest / "README.md").write_text(f"# Placeholder for {git_url}\n")

    def _health_check(self, base_url: str, path: str, timeout: int = 60) -> bool:
        ok, _ = self.health.check(base_url, path, timeout=timeout, simulated=self.docker.simulated)
        return ok

    def _get_commit_hash(self, repo_dir: Path) -> str:
        try:
            out = subprocess.check_output(
                ["git", "-C", str(repo_dir), "rev-parse", "--short", "HEAD"],
                stderr=subprocess.DEVNULL,
            )
            return out.decode().strip()
        except Exception:
            return ""

    def rollback(self, name: str, version: str | None = None, *, use_latest: bool = False) -> dict[str, Any]:
        project = ProjectModel.get(name)
        if not project:
            raise ValueError(f"项目 {name} 不存在")

        if version:
            record = DeployHistoryModel.get_version(name, version)
        elif use_latest:
            record = DeployHistoryModel.get_latest(name)
        else:
            record = DeployHistoryModel.get_previous(name)

        if not record:
            raise ValueError("没有可回滚的版本")

        image_tag = record["image_tag"]
        rolled_version = record["version"]
        config = ProjectModel.get_config(name)
        run_cfg = config.get("run") or {}
        port = int(run_cfg.get("port") or 8080)
        env = config.get("env") or {}
        resources = config.get("resources") or {}

        self.docker.run_container(
            image_tag,
            name,
            port=port,
            env=env,
            cpu=float(resources.get("cpu") or 1.0),
            memory_mb=int(resources.get("memory") or 512),
        )
        project_url = project.get("url") or ""
        ProjectModel.upsert(
            name=name,
            project_type=project["type"],
            config=config,
            status="running",
            url=project_url,
            container_id=project.get("container_id") or "",
            image_tag=image_tag,
            health_status="healthy",
            environment=project.get("environment") or "",
        )
        return {
            "version": rolled_version,
            "image_tag": image_tag,
            "url": project_url,
        }

    def promote_canary(self, name: str) -> dict[str, Any]:
        project = ProjectModel.get(name)
        if not project:
            raise ValueError(f"项目 {name} 不存在")
        config = ProjectModel.get_config(name)
        state = config.get("strategy_state") or {}
        if not state.get("canary_active"):
            raise ValueError("当前无活跃 Canary 部署")
        canary_image = state.get("canary_image") or ""
        run_cfg = config.get("run") or {}
        port = int(run_cfg.get("port") or 8080)
        env = config.get("env") or {}
        resources = config.get("resources") or {}
        domain = (config.get("domain") or {}).get("primary") or ""
        self.strategy.promote_canary(name, canary_image, port, env, resources, domain)
        config["strategy_state"] = {"canary_active": False}
        history = DeployHistoryModel.list_for_project(name, limit=1)
        version = history[0]["version"] if history else "canary"
        ProjectModel.upsert(
            name=name,
            project_type=project["type"],
            config=config,
            status="running",
            url=project.get("url") or "",
            container_id=project.get("container_id") or "",
            image_tag=canary_image,
            health_status="healthy",
            environment=project.get("environment") or "",
        )
        DeployHistoryModel.add(name, f"{version}-promoted", canary_image, "", project.get("environment") or "")
        return {"message": f"Canary 已全量发布 {name}", "image_tag": canary_image}

    def abort_canary(self, name: str) -> dict[str, Any]:
        project = ProjectModel.get(name)
        if not project:
            raise ValueError(f"项目 {name} 不存在")
        config = ProjectModel.get_config(name)
        state = config.get("strategy_state") or {}
        if not state.get("canary_active"):
            raise ValueError("当前无活跃 Canary 部署")
        run_cfg = config.get("run") or {}
        port = int(run_cfg.get("port") or 8080)
        domain = (config.get("domain") or {}).get("primary") or ""
        self.strategy.abort_canary(name, port, domain)
        config["strategy_state"] = {"canary_active": False}
        ProjectModel.upsert(
            name=name,
            project_type=project["type"],
            config=config,
            status="running",
            url=project.get("url") or "",
            container_id=project.get("container_id") or "",
            image_tag=project.get("image_tag") or "",
            health_status=project.get("health_status") or "healthy",
            environment=project.get("environment") or "",
        )
        return {"message": f"Canary 已终止，恢复旧版本 {name}"}
