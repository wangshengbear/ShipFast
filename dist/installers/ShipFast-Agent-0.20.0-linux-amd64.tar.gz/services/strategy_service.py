"""shipfast-agent/services/strategy_service.py — 蓝绿 / Canary 部署策略"""
from __future__ import annotations

import logging
from typing import Any

from services.docker_service import DockerService
from services.health_service import HealthService, health_from_config
from services.nginx_service import NginxService

logger = logging.getLogger(__name__)


class StrategyService:
    """rolling / blue_green / canary 部署策略"""

    def __init__(self) -> None:
        self.docker = DockerService()
        self.nginx = NginxService()
        self.health = HealthService()

    def deploy_rolling(
        self,
        name: str,
        image_tag: str,
        port: int,
        env: dict[str, str],
        resources: dict[str, Any],
    ) -> str:
        return self.docker.run_container(
            image_tag,
            name,
            port=port,
            env=env,
            cpu=float(resources.get("cpu") or 1.0),
            memory_mb=int(resources.get("memory") or 512),
        )

    def deploy_blue_green(
        self,
        name: str,
        image_tag: str,
        port: int,
        env: dict[str, str],
        resources: dict[str, Any],
        payload: dict[str, Any],
    ) -> tuple[str, str, dict[str, Any]]:
        """蓝绿：候选容器健康检查后切换主容器"""
        bg = (payload.get("strategy") or {}).get("blue_green") or {}
        offset = int(bg.get("port_offset") or 1000)
        candidate_name = f"{name}-bg-candidate"
        candidate_port = port + offset

        self.docker.run_container(
            image_tag,
            candidate_name,
            port=candidate_port,
            env=env,
            cpu=float(resources.get("cpu") or 1.0),
            memory_mb=int(resources.get("memory") or 512),
        )

        health_cfg = health_from_config(payload)
        candidate_url = f"http://127.0.0.1:{candidate_port}"
        healthy, health_status = self.health.check(
            candidate_url,
            path=health_cfg["path"],
            timeout=health_cfg["timeout"],
            interval=min(health_cfg["interval"], 10),
            expected_status=health_cfg["expected_status"],
            simulated=self.docker.simulated,
        )
        if not healthy:
            self.docker.stop_container(candidate_name)
            raise ValueError(f"蓝绿候选版本健康检查失败: {health_status}")

        container_id = self.docker.run_container(
            image_tag,
            name,
            port=port,
            env=env,
            cpu=float(resources.get("cpu") or 1.0),
            memory_mb=int(resources.get("memory") or 512),
        )
        self.docker.stop_container(candidate_name)

        meta = {"strategy": "blue_green", "health_status": health_status}
        return container_id, candidate_url, meta

    def deploy_canary(
        self,
        name: str,
        image_tag: str,
        port: int,
        env: dict[str, str],
        resources: dict[str, Any],
        payload: dict[str, Any],
        has_existing: bool,
    ) -> tuple[str, str, dict[str, Any]]:
        """Canary：新流量百分比到候选容器，需手动 promote 或 auto promote"""
        canary_cfg = (payload.get("strategy") or {}).get("canary") or {}
        percent = max(1, min(100, int(canary_cfg.get("percent") or 10)))
        offset = int(canary_cfg.get("port_offset") or 1001)
        canary_name = f"{name}-canary"
        canary_port = port + offset

        if not has_existing:
            container_id = self.docker.run_container(
                image_tag, name, port=port, env=env,
                cpu=float(resources.get("cpu") or 1.0),
                memory_mb=int(resources.get("memory") or 512),
            )
            return container_id, f"http://127.0.0.1:{port}", {
                "strategy": "canary",
                "canary_active": False,
                "canary_percent": 0,
            }

        self.docker.run_container(
            image_tag,
            canary_name,
            port=canary_port,
            env=env,
            cpu=float(resources.get("cpu") or 1.0),
            memory_mb=int(resources.get("memory") or 512),
        )

        health_cfg = health_from_config(payload)
        canary_url = f"http://127.0.0.1:{canary_port}"
        healthy, health_status = self.health.check(
            canary_url,
            path=health_cfg["path"],
            timeout=health_cfg["timeout"],
            interval=min(health_cfg["interval"], 10),
            expected_status=health_cfg["expected_status"],
            simulated=self.docker.simulated,
        )
        if not healthy:
            self.docker.stop_container(canary_name)
            raise ValueError(f"Canary 健康检查失败: {health_status}")

        main_url = f"http://127.0.0.1:{port}"
        domain_cfg = payload.get("domain") or {}
        primary = domain_cfg.get("primary") or ""
        if primary:
            scheme = "https" if domain_cfg.get("ssl") == "auto" else "http"
            main_url = f"{scheme}://{primary}"

        meta = {
            "strategy": "canary",
            "canary_active": True,
            "canary_percent": percent,
            "canary_port": canary_port,
            "canary_image": image_tag,
            "health_status": health_status,
            "promote_after": int(canary_cfg.get("promote_after") or 0),
        }
        # 主容器保持旧版本运行
        stats = self.docker.get_container_stats(name)
        container_id = stats.get("id") or f"canary-{name}"
        return container_id, main_url, meta

    def promote_canary(
        self,
        name: str,
        image_tag: str,
        port: int,
        env: dict[str, str],
        resources: dict[str, Any],
        domain: str,
    ) -> None:
        """将 Canary 提升为 100% 流量"""
        canary_name = f"{name}-canary"
        self.docker.run_container(
            image_tag or self._canary_image(canary_name),
            name,
            port=port,
            env=env,
            cpu=float(resources.get("cpu") or 1.0),
            memory_mb=int(resources.get("memory") or 512),
        )
        self.docker.stop_container(canary_name)
        if domain:
            self.nginx.configure_proxy(name, domain, port)

    def abort_canary(self, name: str, port: int, domain: str) -> None:
        """终止 Canary，恢复全量旧版本"""
        canary_name = f"{name}-canary"
        self.docker.stop_container(canary_name)
        if domain:
            self.nginx.configure_proxy(name, domain, port)

    def _canary_image(self, canary_name: str) -> str:
        stats = self.docker.get_container_stats(canary_name)
        return stats.get("image") or "shipfast/unknown:latest"
