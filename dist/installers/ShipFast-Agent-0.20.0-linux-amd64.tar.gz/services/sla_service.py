"""shipfast-agent/services/sla_service.py — SLA 与可用性"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any

from models import HealthEventModel, ProjectModel

logger = logging.getLogger(__name__)


class SLAService:
    """基于健康检查历史的 SLA 统计"""

    def status(self, name: str, hours: int = 24) -> dict[str, Any]:
        project = ProjectModel.get(name)
        if not project:
            raise ValueError(f"项目 {name} 不存在")
        since = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
        events = HealthEventModel.list_since(name, since)
        total = len(events)
        failed = sum(1 for e in events if e.get("status") != "healthy")
        uptime = 100.0 if total == 0 else round((total - failed) / total * 100, 2)
        config = ProjectModel.get_config(name)
        resources = config.get("resources") or {}
        cpu = float(resources.get("cpu") or 1.0)
        mem_gb = float(resources.get("memory") or 512) / 1024.0
        cost = round(cpu * 15 + mem_gb * 5, 2)
        return {
            "project": name,
            "window_hours": hours,
            "uptime_percent": uptime,
            "checks_total": total,
            "checks_failed": failed,
            "cost_estimate_usd": cost,
            "current_health": project.get("health_status") or "unknown",
        }

    def report(self, hours: int = 24) -> list[dict[str, Any]]:
        out = []
        for p in ProjectModel.list_all():
            try:
                out.append(self.status(p["name"], hours))
            except ValueError:
                continue
        return out
