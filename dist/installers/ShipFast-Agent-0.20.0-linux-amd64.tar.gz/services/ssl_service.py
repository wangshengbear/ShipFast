"""shipfast-agent/services/ssl_service.py — Let's Encrypt 证书申请"""
from __future__ import annotations

import logging
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)

CERT_BASE = Path("/etc/letsencrypt/live")


class SSLService:
    """Let's Encrypt 证书管理"""

    def request_certificate(self, domain: str) -> tuple[str, str]:
        """
        申请 SSL 证书，返回 (cert_path, key_path)。
        失败时返回空字符串。
        """
        if not self._certbot_available():
            logger.warning("certbot 不可用，跳过 SSL 申请")
            return "", ""

        try:
            subprocess.run(
                [
                    "certbot", "certonly", "--nginx",
                    "-d", domain,
                    "--non-interactive",
                    "--agree-tos",
                    "--register-unsafely-without-email",
                ],
                check=True,
                capture_output=True,
                timeout=300,
            )
            cert_dir = CERT_BASE / domain
            return str(cert_dir / "fullchain.pem"), str(cert_dir / "privkey.pem")
        except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired) as exc:
            logger.warning("SSL 证书申请失败: %s", exc)
            return "", ""

    def _certbot_available(self) -> bool:
        from shutil import which
        return which("certbot") is not None
