"""shipfast-agent/services/incident_service.py — 告警事件 / 故障管理"""
from __future__ import annotations

import logging
from typing import Any

from models import IncidentModel, ProjectModel

logger = logging.getLogger(__name__)


class IncidentService:
    """将告警升级为可跟踪的 incident"""

    def open_from_alert(self, project_name: str, rule_name: str, severity: str, message: str) -> dict[str, Any]:
        existing = IncidentModel.find_open(project_name, rule_name)
        if existing:
            return IncidentModel.touch(existing["id"], message)
        return IncidentModel.create(project_name, rule_name, severity, message)

    def list_incidents(self, limit: int = 50, status: str = "") -> list[dict[str, Any]]:
        return IncidentModel.list_recent(limit, status)

    def get(self, incident_id: str) -> dict[str, Any]:
        row = IncidentModel.get(incident_id)
        if not row:
            raise ValueError(f"incident {incident_id} 不存在")
        return row

    def ack(self, incident_id: str, actor: str = "cli") -> dict[str, Any]:
        return IncidentModel.update_status(incident_id, "acked", actor)

    def resolve(self, incident_id: str, actor: str = "cli") -> dict[str, Any]:
        return IncidentModel.update_status(incident_id, "resolved", actor)

    def auto_resolve_healthy(self, project_name: str) -> None:
        project = ProjectModel.get(project_name)
        if not project:
            return
        if project.get("health_status") == "healthy" and project.get("status") == "running":
            for inc in IncidentModel.list_open_for_project(project_name):
                IncidentModel.update_status(inc["id"], "resolved", "auto")
