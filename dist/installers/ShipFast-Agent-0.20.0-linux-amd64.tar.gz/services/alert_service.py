"""shipfast-agent/services/alert_service.py — 告警规则引擎"""
from __future__ import annotations

import logging
from typing import Any

from models import AlertModel, ProjectModel
from services.notify_service import NotifyService

logger = logging.getLogger(__name__)

CONDITIONS = {
    "health_error": lambda p: p.get("health_status") == "error",
    "status_stopped": lambda p: p.get("status") == "stopped",
    "status_error": lambda p: p.get("status") == "error",
}


class AlertService:
    """评估 shipfast.yaml alerts 规则并触发通知"""

    def __init__(self) -> None:
        self.notify = NotifyService()

    def evaluate_all(self) -> list[dict[str, Any]]:
        fired: list[dict[str, Any]] = []
        for project in ProjectModel.list_all():
            fired.extend(self.evaluate_project(project["name"]))
        return fired

    def evaluate_project(self, name: str) -> list[dict[str, Any]]:
        project = ProjectModel.get(name)
        if not project:
            return []
        config = ProjectModel.get_config(name)
        rules = config.get("alerts") or []
        if not rules:
            return []

        fired: list[dict[str, Any]] = []
        for rule in rules:
            cond = rule.get("condition") or rule.get("when") or ""
            fn = CONDITIONS.get(cond)
            if not fn:
                continue
            if not fn(project):
                continue
            rule_name = rule.get("name") or cond
            if AlertModel.recently_fired(name, rule_name, cooldown_sec=int(rule.get("cooldown") or 300)):
                continue
            event = AlertModel.fire(
                project_name=name,
                rule_name=rule_name,
                severity=rule.get("severity") or "warning",
                message=f"{name}: {rule_name} ({cond})",
            )
            fired.append(event)
            try:
                from services.incident_service import IncidentService
                IncidentService().open_from_alert(
                    name, rule_name, rule.get("severity") or "warning", event["message"]
                )
            except Exception as exc:
                logger.debug("incident 创建跳过: %s", exc)
            if rule.get("notify", True):
                notify_cfg = config.get("notifications") or {}
                channels = {}
                if notify_cfg.get("webhook"):
                    channels["webhook"] = notify_cfg["webhook"]
                if notify_cfg.get("slack_webhook"):
                    channels["slack_webhook"] = notify_cfg["slack_webhook"]
                self.notify.send(
                    "alert.fired",
                    {"name": name, "message": event["message"], "success": False, "environment": project.get("environment") or ""},
                    channels,
                )
        return fired

    def list_active(self, limit: int = 50) -> list[dict[str, Any]]:
        return AlertModel.list_recent(limit)
