"""shipfast-agent/services/k8s_service.py — Kubernetes 部署适配"""
from __future__ import annotations

import logging
import subprocess
import textwrap
from pathlib import Path
from shutil import which
from typing import Any, Optional

logger = logging.getLogger(__name__)


def resolve_target(k8s_cfg: dict[str, Any], run_cfg: dict[str, Any] | None = None) -> tuple[str, str, int]:
    """解析多集群配置 → namespace, context, replicas"""
    run_cfg = run_cfg or {}
    cluster_name = k8s_cfg.get("cluster") or ""
    clusters = k8s_cfg.get("clusters") or {}
    if cluster_name and cluster_name in clusters:
        spec = clusters[cluster_name] or {}
        ns = spec.get("namespace") or k8s_cfg.get("namespace") or "default"
        ctx = spec.get("context") or k8s_cfg.get("context") or ""
        replicas = int(spec.get("replicas") or k8s_cfg.get("replicas") or run_cfg.get("replicas") or 1)
        return ns, ctx, replicas
    ns = k8s_cfg.get("namespace") or "default"
    ctx = k8s_cfg.get("context") or ""
    replicas = int(k8s_cfg.get("replicas") or run_cfg.get("replicas") or 1)
    return ns, ctx, replicas


def list_clusters(k8s_cfg: dict[str, Any]) -> list[dict[str, Any]]:
    clusters = k8s_cfg.get("clusters") or {}
    active = k8s_cfg.get("cluster") or ""
    out = []
    for name, spec in clusters.items():
        spec = spec or {}
        out.append({
            "name": name,
            "context": spec.get("context") or "",
            "namespace": spec.get("namespace") or "default",
            "replicas": spec.get("replicas") or 1,
            "active": name == active,
        })
    if not out and k8s_cfg.get("enabled"):
        ns, ctx, replicas = resolve_target(k8s_cfg)
        out.append({"name": "default", "context": ctx, "namespace": ns, "replicas": replicas, "active": True})
    return out


class K8sService:
    """kubectl 部署封装，无 kubectl 时模拟"""

    def __init__(self) -> None:
        self.simulated = which("kubectl") is None
        if self.simulated:
            logger.warning("kubectl 不可用，K8s 部署使用模拟模式")

    def deploy(
        self,
        name: str,
        image: str,
        namespace: str = "default",
        context: str = "",
        replicas: int = 1,
        port: int = 8080,
        env: Optional[dict[str, str]] = None,
        manifest_path: str = "",
    ) -> dict[str, Any]:
        if manifest_path and Path(manifest_path).exists():
            return self._apply_file(manifest_path, context, namespace, image)

        manifest = self._generate_deployment(name, image, namespace, replicas, port, env or {})
        tmp = Path(f"/tmp/shipfast-{name}-deploy.yaml")
        if self.simulated:
            tmp = Path.cwd() / f".shipfast-k8s-{name}.yaml"
        tmp.write_text(manifest, encoding="utf-8")
        return self._apply_file(str(tmp), context, namespace, image)

    def status(self, name: str, namespace: str = "default", context: str = "") -> dict[str, Any]:
        if self.simulated:
            return {
                "mode": "simulated",
                "deployment": name,
                "ready_replicas": 1,
                "replicas": 1,
            }
        cmd = ["kubectl", "get", "deploy", name, "-n", namespace, "-o", "json"]
        if context:
            cmd.extend(["--context", context])
        try:
            out = subprocess.check_output(cmd, stderr=subprocess.PIPE, timeout=30)
            import json
            data = json.loads(out)
            status = data.get("status") or {}
            return {
                "mode": "kubernetes",
                "deployment": name,
                "ready_replicas": status.get("readyReplicas", 0),
                "replicas": status.get("replicas", 0),
            }
        except subprocess.CalledProcessError as exc:
            return {"mode": "kubernetes", "error": exc.stderr.decode()[:200]}

    def _apply_file(self, path: str, context: str, namespace: str, image: str) -> dict[str, Any]:
        if self.simulated:
            logger.info("[K8s 模拟] apply %s image=%s ns=%s", path, image, namespace)
            return {
                "mode": "simulated",
                "manifest": path,
                "image": image,
                "namespace": namespace,
            }
        cmd = ["kubectl", "apply", "-f", path, "-n", namespace]
        if context:
            cmd.extend(["--context", context])
        subprocess.run(cmd, check=True, capture_output=True, timeout=120)
        logger.info("K8s 部署已 apply: %s", path)
        return {"mode": "kubernetes", "manifest": path, "image": image, "namespace": namespace}

    def _generate_deployment(
        self,
        name: str,
        image: str,
        namespace: str,
        replicas: int,
        port: int,
        env: dict[str, str],
    ) -> str:
        env_lines = ""
        for k, v in env.items():
            env_lines += f"\n            - name: {k}\n              value: \"{v}\""
        return textwrap.dedent(f"""
            apiVersion: apps/v1
            kind: Deployment
            metadata:
              name: {name}
              namespace: {namespace}
              labels:
                app: {name}
                managed-by: shipfast
            spec:
              replicas: {replicas}
              selector:
                matchLabels:
                  app: {name}
              template:
                metadata:
                  labels:
                    app: {name}
                spec:
                  containers:
                  - name: {name}
                    image: {image}
                    ports:
                    - containerPort: {port}
                    env:{env_lines or " []"}
            ---
            apiVersion: v1
            kind: Service
            metadata:
              name: {name}
              namespace: {namespace}
            spec:
              selector:
                app: {name}
              ports:
              - port: {port}
                targetPort: {port}
        """).strip() + "\n"
